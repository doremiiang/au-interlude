INTERLUDE — UPDATE DATA WHATSAPP MESSAGES

ISI PAKET
- data/messages.js
  Aggregator utama. File ini disertakan sebagai referensi dan tidak diubah.
- data/messages/*.js
  Tiga belas modul percakapan yang sudah diperluas.
- VALIDATION.txt
  Ringkasan jumlah pesan dan hasil pemeriksaan.

CARA MEMASANG
1. Ekstrak ZIP di komputer.
2. Dari folder hasil ekstrak, salin folder `data/messages/` ke root repository Interlude.
3. Pilih Replace/Timpa saat diminta untuk file yang namanya sama.
4. `data/messages.js` tidak wajib ditimpa karena isinya identik dengan aggregator di repository. File tersebut disertakan agar struktur paket lengkap dan mudah dicocokkan.
5. Jangan mengganti `data/apps.js`, `data/timeline.js`, `js/apps/whatsapp.js`, atau file JavaScript lain. File-file tersebut tidak diubah.
6. Jalankan preview lokal/GitHub Pages/Vercel dan periksa thread WhatsApp.

CATATAN STRUKTUR
Repository yang kamu unggah menggunakan pola modular: `data/messages.js` mengimpor setiap thread dari `data/messages/*.js`. Karena itu, konten percakapan perlu dipasang ke 13 file modul di dalam folder tersebut, bukan digabung menjadi satu array besar di aggregator. Pola impor/ekspor yang sudah ada dipertahankan.

PEMELIHARAAN DATA
- Seluruh 607 pesan lama dipertahankan beserta isi dan properti lamanya.
- ID pesan disusun ulang secara kronologis per thread agar tetap unik dan berurutan setelah pesan baru disisipkan.
- Rentang tanggal mengikuti timeline repository: 14 September sampai 30 Oktober 2026.
- Tidak ada perubahan pada renderer, daftar kontak, timeline, CSS, HTML, atau file JavaScript di luar data percakapan.
