export const SAMARA_MESSAGES = [
  {
    "id": "mara-001",
    "direction": "incoming",
    "type": "photo",
    "mediaUrl": "/assets/images/chats/mara_telur_gulung.jpg",
    "text": "Qil, inget jajanan ini ga? Kita jaman SD sering banget beli sampe dipalakin abangnya gara-gara lu ngutang.",
    "date": "2026-09-16",
    "time": "13:10"
  },
  {
    "id": "mara-002",
    "direction": "outgoing",
    "text": "Fitnah. Mana ada gue ngutang. Itu mah memori masa kecil lu aja yang halu.",
    "date": "2026-09-16",
    "time": "13:25"
  },
  {
    "id": "mara-003",
    "direction": "incoming",
    "text": "Dih ngeles mulu dari SD ga pernah berubah.",
    "date": "2026-09-16",
    "time": "13:27"
  },
  {
    "id": "mara-004",
    "direction": "incoming",
    "text": "Sibuk ga lu hari ini? Temenin gue fitting bridesmaid buat nikahan si Sasa dong minggu depan.",
    "date": "2026-09-21",
    "time": "10:00"
  },
  {
    "id": "mara-005",
    "direction": "outgoing",
    "text": "Gue lagi di studio numpuk tugas maket, Mar. Jangan ngadi-ngadi deh.",
    "date": "2026-09-21",
    "time": "10:15"
  },
  {
    "id": "mara-006",
    "direction": "incoming",
    "text": "Yaudah iya arsitek sibuk. Btw, Panji semalem nge-like foto reels gue jaman KKN dulu. Kenapa tuh laki lu, kepo ya liat arsip lama?",
    "date": "2026-09-21",
    "time": "10:18"
  },
  {
    "id": "mara-007",
    "direction": "outgoing",
    "text": "Hah? Sumpah? Kurang kerjaan banget Panji nge-like postingan taun jebot.",
    "date": "2026-09-21",
    "time": "10:20"
  },
  {
    "id": "mara-008",
    "direction": "incoming",
    "text": "Wkwkwk cemburu ya? Lucu bgt lu bedua posesif gemes gitu.",
    "date": "2026-09-21",
    "time": "10:22"
  },
  {
    "id": "mara-009",
    "direction": "outgoing",
    "text": "Dih najis. Ogah banget.",
    "date": "2026-09-21",
    "time": "10:25"
  },
  {
    "id": "mara-010",
    "direction": "incoming",
    "text": "Fitting tadi akhirnya kelar. Gue sama Sasa malah debat soal warna pita setengah jam",
    "date": "2026-09-21",
    "time": "18:30"
  },
  {
    "id": "mara-011",
    "direction": "outgoing",
    "text": "Kebayang. Lu kalau udah bahas warna bisa lupa waktu",
    "date": "2026-09-21",
    "time": "18:33"
  },
  {
    "id": "mara-012",
    "direction": "incoming",
    "text": "Ya karena kalian cowok kalau disuruh milih cuma jawab bagus atau engga",
    "date": "2026-09-21",
    "time": "18:35"
  },
  {
    "id": "mara-013",
    "direction": "outgoing",
    "text": "Emang harus jawab apa? Pantone sekalian?",
    "date": "2026-09-21",
    "time": "18:37"
  },
  {
    "id": "mara-014",
    "direction": "incoming",
    "text": "Boleh, biar ada gunanya punya temen arsitek",
    "date": "2026-09-21",
    "time": "18:39"
  },
  {
    "id": "mara-015",
    "direction": "incoming",
    "text": "Qil, sumpah ya customer olshop gue hari ini pengen banget gue ajak ribut.",
    "date": "2026-09-27",
    "time": "15:00"
  },
  {
    "id": "mara-016",
    "direction": "incoming",
    "text": "Udah salah, bawel, nawar sadis, giliran dikasih barangnya protes mulu.",
    "date": "2026-09-27",
    "time": "15:01"
  },
  {
    "id": "mara-017",
    "direction": "outgoing",
    "text": "Sabar Mar, namanya juga cari uang emang harus diuji kesabarannya tiap hari wkwk.",
    "date": "2026-09-27",
    "time": "15:10"
  },
  {
    "id": "mara-018",
    "direction": "incoming",
    "type": "voice",
    "duration": "0:11",
    "transcript": "Mau nangis rasanya pengen banting hp. Emang paling bener jadi pengangguran kaya lu dulu kan.",
    "date": "2026-09-27",
    "time": "15:12"
  },
  {
    "id": "mara-019",
    "direction": "outgoing",
    "text": "Sembarangan ngatain gue pengangguran. Tugas studio numpuk gini dibilang pengangguran.",
    "date": "2026-09-27",
    "time": "15:16"
  },
  {
    "id": "mara-020",
    "direction": "incoming",
    "text": "Customer tadi akhirnya minta maaf. Katanya dia salah baca ukuran",
    "date": "2026-09-27",
    "time": "19:00"
  },
  {
    "id": "mara-021",
    "direction": "outgoing",
    "text": "Nah kan. Tadi lu udah mau perang dunia",
    "date": "2026-09-27",
    "time": "19:03"
  },
  {
    "id": "mara-022",
    "direction": "incoming",
    "text": "Tetep aja bikin darah tinggi. Besok gue pasang tabel ukuran yang lebih jelas",
    "date": "2026-09-27",
    "time": "19:05"
  },
  {
    "id": "mara-023",
    "direction": "outgoing",
    "text": "Bagus. Biar lu ga perlu voice note sambil misuh-misuh lagi",
    "date": "2026-09-27",
    "time": "19:07"
  },
  {
    "id": "mara-024",
    "direction": "incoming",
    "text": "Qil, kemarin sore gue ga sengaja papasan sama cowok lu eh salah, maksudnya abang lu si Elvian di resto daerah Senopati.",
    "date": "2026-10-04",
    "time": "11:00"
  },
  {
    "id": "mara-025",
    "direction": "outgoing",
    "text": "Oh Bang Pian? Emang dia demen jalan mulu tuh orang. Dia nyapa lu?",
    "date": "2026-10-04",
    "time": "11:15"
  },
  {
    "id": "mara-026",
    "direction": "incoming",
    "text": "Nyapa sambil senyum-senyum songong mirip banget kayak muka lu pas lagi ngeledek gue.",
    "date": "2026-10-04",
    "time": "11:18"
  },
  {
    "id": "mara-027",
    "direction": "outgoing",
    "text": "Sialan, gantengan juga gue kemana-mana.",
    "date": "2026-10-04",
    "time": "11:20"
  },
  {
    "id": "mara-028",
    "direction": "incoming",
    "text": "Idih pede gila.",
    "date": "2026-10-04",
    "time": "11:22"
  },
  {
    "id": "mara-029",
    "direction": "incoming",
    "text": "Bang Pian tadi sempet nanya kabar lu pas papasan. Kayaknya dia inget gue temen SD lu",
    "date": "2026-10-04",
    "time": "11:30"
  },
  {
    "id": "mara-030",
    "direction": "outgoing",
    "text": "Dia emang gampang inget orang, apalagi kalau orangnya pernah jadi bahan bercandaan",
    "date": "2026-10-04",
    "time": "11:33"
  },
  {
    "id": "mara-031",
    "direction": "incoming",
    "text": "Eh weekend ini lu ada waktu ga? Temenin gue nyari kado buat nyokap yuk.",
    "date": "2026-10-12",
    "time": "14:00"
  },
  {
    "id": "mara-032",
    "direction": "outgoing",
    "text": "Hari Sabtu gue bisa. Jam berapa emang?",
    "date": "2026-10-12",
    "time": "14:10"
  },
  {
    "id": "mara-033",
    "direction": "incoming",
    "text": "Jam 2 siang di Summarecon Bekasi ya. Jangan ngaret lu biasa jam karet.",
    "date": "2026-10-12",
    "time": "14:12"
  },
  {
    "id": "mara-034",
    "direction": "outgoing",
    "text": "Iya bawel.",
    "date": "2026-10-12",
    "time": "14:15"
  },
  {
    "id": "mara-035",
    "direction": "incoming",
    "text": "Hahaha. Btw gue jadi cari kado Sabtu ini. Jangan telat, gue udah bikin list",
    "date": "2026-10-12",
    "time": "14:20"
  },
  {
    "id": "mara-036",
    "direction": "outgoing",
    "text": "List lu pasti panjang banget",
    "date": "2026-10-12",
    "time": "14:22"
  },
  {
    "id": "mara-037",
    "direction": "incoming",
    "text": "Tiga toko doang. Gue janji",
    "date": "2026-10-12",
    "time": "14:24"
  },
  {
    "id": "mara-038",
    "direction": "outgoing",
    "text": "Janji lu ga pernah bisa dipercaya",
    "date": "2026-10-12",
    "time": "14:26"
  },
  {
    "id": "mara-039",
    "direction": "incoming",
    "text": "Makasih udah nemenin kemarin. Nyokap gue suka kadonya, katanya pilihan lu bagus",
    "date": "2026-10-18",
    "time": "17:00"
  },
  {
    "id": "mara-040",
    "direction": "outgoing",
    "text": "Sama-sama. Untung ga disuruh tuker",
    "date": "2026-10-18",
    "time": "17:03"
  },
  {
    "id": "mara-041",
    "direction": "incoming",
    "text": "Lu juga jangan lupa istirahat. Gue tau lu habis banyak kerjaan minggu ini",
    "date": "2026-10-18",
    "time": "17:05"
  },
  {
    "id": "mara-042",
    "direction": "outgoing",
    "text": "Siap, Bu Samara",
    "date": "2026-10-18",
    "time": "17:07"
  },
  {
    "id": "mara-043",
    "direction": "incoming",
    "type": "call",
    "status": "missed",
    "date": "2026-10-20",
    "time": "19:10"
  },
  {
    "id": "mara-044",
    "direction": "incoming",
    "text": "Shaqil Naraya! Lu diinfus gara-gara apa lagi astaga!",
    "date": "2026-10-20",
    "time": "19:12"
  },
  {
    "id": "mara-045",
    "direction": "incoming",
    "text": "Gue liat story IG Panji serem bgt tangan lu ditusuk jarum.",
    "date": "2026-10-20",
    "time": "19:13"
  },
  {
    "id": "mara-046",
    "direction": "outgoing",
    "text": "Buset panik amat. Itu cuma vitamin doang Mar, bukan sakit parah.",
    "date": "2026-10-20",
    "time": "19:20"
  },
  {
    "id": "mara-047",
    "direction": "incoming",
    "text": "Ya makanya jangan kerja mulu kayak kerja buat bayar utang negara. Kalo lu tumbang kan repot semua orang.",
    "date": "2026-10-20",
    "time": "19:22"
  },
  {
    "id": "mara-048",
    "direction": "incoming",
    "type": "sticker",
    "mediaUrl": "/assets/stickers/mara_angry.png",
    "date": "2026-10-20",
    "time": "19:23"
  },
  {
    "id": "mara-049",
    "direction": "outgoing",
    "text": "Iya ibuku kedua, cerewet banget sumpah.",
    "date": "2026-10-20",
    "time": "19:26"
  },
  {
    "id": "mara-050",
    "direction": "incoming",
    "text": "Biarin. Ntar malem mau dibawain sop buah ga sm Panji? Kalo pacar lu males, biar gue pesenin ojol ke apart lu.",
    "date": "2026-10-20",
    "time": "19:30"
  },
  {
    "id": "mara-051",
    "direction": "outgoing",
    "text": "Udah dibawain bubur sama Panji. Aman kok, gausah repot-repot pesenin.",
    "date": "2026-10-20",
    "time": "19:35"
  },
  {
    "id": "mara-052",
    "direction": "incoming",
    "text": "Gue ga jadi bawain sop buah waktu itu karena Panji udah bawain bubur. Tapi gue ada stok buah potong, mau?",
    "date": "2026-10-20",
    "time": "20:00"
  },
  {
    "id": "mara-053",
    "direction": "outgoing",
    "text": "Ga usah Mar, stok makanan di apart masih banyak. Makasih ya",
    "date": "2026-10-20",
    "time": "20:03"
  },
  {
    "id": "mara-054",
    "direction": "incoming",
    "text": "Oke. Kalau udah beneran enakan baru kabarin. Kita ngopi, ga perlu lama",
    "date": "2026-10-20",
    "time": "20:05"
  },
  {
    "id": "mara-055",
    "direction": "outgoing",
    "text": "Iya. Gue juga udah bosen liat plafon apart",
    "date": "2026-10-20",
    "time": "20:07"
  },
  {
    "id": "mara-056",
    "direction": "incoming",
    "text": "Udah pulih beneran? Jangan cuma bilang iya supaya orang ga cerewet",
    "date": "2026-10-24",
    "time": "12:00"
  },
  {
    "id": "mara-057",
    "direction": "outgoing",
    "text": "Udah. Hari ini udah bisa jalan agak lama kok",
    "date": "2026-10-24",
    "time": "12:03"
  },
  {
    "id": "mara-058",
    "direction": "incoming",
    "text": "Oke. Tapi jangan langsung sok kuat. Pelan-pelan aja",
    "date": "2026-10-24",
    "time": "12:05"
  },
  {
    "id": "mara-059",
    "direction": "outgoing",
    "text": "Iya, Mama",
    "date": "2026-10-24",
    "time": "12:07"
  },
  {
    "id": "mara-060",
    "direction": "incoming",
    "type": "photo",
    "mediaUrl": "/assets/images/chats/mara_earrings.jpg",
    "text": "Qil, anting baru gue bagus ga? Cocok pake baju hitam ga nanti buat kondangan?",
    "date": "2026-10-28",
    "time": "16:00"
  },
  {
    "id": "mara-061",
    "direction": "outgoing",
    "text": "Biasa aja. Tapi masuk kok kalo dipairing sama dress hitam.",
    "date": "2026-10-28",
    "time": "16:15"
  },
  {
    "id": "mara-062",
    "direction": "incoming",
    "text": "Jawabannya lempeng banget emang dasar cowok ga ngerti estetika aksesoris.",
    "date": "2026-10-28",
    "time": "16:18"
  },
  {
    "id": "mara-063",
    "direction": "outgoing",
    "text": "Bodo amat. Urusin tuh toko olshop lu daripada nanya anting mulu.",
    "date": "2026-10-28",
    "time": "16:20"
  },
  {
    "id": "mara-064",
    "direction": "incoming",
    "type": "sticker",
    "mediaUrl": "/assets/stickers/mara_rolling_eyes.png",
    "date": "2026-10-28",
    "time": "16:22"
  },
  {
    "id": "mara-065",
    "direction": "incoming",
    "text": "Antingnya jadi gue pake dress hitam. Ternyata bagus juga kata Sasa",
    "date": "2026-10-28",
    "time": "16:30"
  },
  {
    "id": "mara-066",
    "direction": "outgoing",
    "text": "Kan gue bilang cocok. Lu aja yang ga percaya",
    "date": "2026-10-28",
    "time": "16:33"
  },
  {
    "id": "mara-067",
    "direction": "incoming",
    "text": "Gue percaya, cuma butuh validasi tambahan wkwk",
    "date": "2026-10-28",
    "time": "16:35"
  },
  {
    "id": "mara-068",
    "direction": "outgoing",
    "text": "Cari validasi ke orang yang bener, jangan ke gue",
    "date": "2026-10-28",
    "time": "16:37"
  },
  {
    "id": "mara-069",
    "direction": "incoming",
    "text": "Weekend ini kalau lu senggang, gue mau balikin jaket yang ketinggalan di mobil lu",
    "date": "2026-10-30",
    "time": "16:00"
  },
  {
    "id": "mara-070",
    "direction": "outgoing",
    "text": "Oh iya. Bawa aja pas nongkrong, kalau jadi",
    "date": "2026-10-30",
    "time": "16:03"
  },
  {
    "id": "mara-071",
    "direction": "incoming",
    "text": "Oke. Jangan batal gara-gara pacar lu ngajak rebahan",
    "date": "2026-10-30",
    "time": "16:05"
  },
  {
    "id": "mara-072",
    "direction": "outgoing",
    "text": "Bacot. Gue bisa atur jadwal sendiri",
    "date": "2026-10-30",
    "time": "16:07"
  }
];
