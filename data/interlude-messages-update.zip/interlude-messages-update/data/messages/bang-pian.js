export const PIAN_MESSAGES = [
  {
    "id": "pian-001",
    "direction": "incoming",
    "type": "call",
    "status": "missed",
    "date": "2026-09-15",
    "time": "07:30"
  },
  {
    "id": "pian-002",
    "direction": "incoming",
    "text": "Dek, pinjem mobil lu ya! Gue telat mampus, mobil gue bannya kempes.",
    "date": "2026-09-15",
    "time": "07:31"
  },
  {
    "id": "pian-003",
    "direction": "outgoing",
    "text": "Anjir pantesan kunci mobil gue di atas kulkas ga ada. Kebiasaan banget lu bang maen bawa aja.",
    "date": "2026-09-15",
    "time": "08:00"
  },
  {
    "id": "pian-004",
    "direction": "incoming",
    "text": "Wkwkwk sorry dek, ntar baliknya gue isiin bensin full deh. Semangat ngantornya pake ojol ya.",
    "date": "2026-09-15",
    "time": "08:15"
  },
  {
    "id": "pian-005",
    "direction": "incoming",
    "text": "Mobil lu udah gue balikin. Bensin gue isi full beneran, cek aja",
    "date": "2026-09-15",
    "time": "18:00"
  },
  {
    "id": "pian-006",
    "direction": "outgoing",
    "text": "Tumben nepatin janji. Makasih bang",
    "date": "2026-09-15",
    "time": "18:03"
  },
  {
    "id": "pian-007",
    "direction": "incoming",
    "text": "Jangan kaget kalau besok gue pinjem lagi",
    "date": "2026-09-15",
    "time": "18:05"
  },
  {
    "id": "pian-008",
    "direction": "outgoing",
    "text": "Mending lu benerin ban mobil lu sendiri",
    "date": "2026-09-15",
    "time": "18:07"
  },
  {
    "id": "pian-009",
    "direction": "incoming",
    "text": "Lu weekend ini balik ke rumah ga?",
    "date": "2026-09-18",
    "time": "16:00"
  },
  {
    "id": "pian-010",
    "direction": "outgoing",
    "text": "Engga kayaknya, mau nugas di apart aja gue males gerak. Kenapa?",
    "date": "2026-09-18",
    "time": "16:15"
  },
  {
    "id": "pian-011",
    "direction": "incoming",
    "text": "Papi masak banyak, ntar paling nyuruh gue nganterin rantang ke tempat lu.",
    "date": "2026-09-18",
    "time": "16:20"
  },
  {
    "id": "pian-012",
    "direction": "outgoing",
    "text": "Nah itu boleh. Bawain sekalian ya bang, gue emang lagi males keluar nyari makan.",
    "date": "2026-09-18",
    "time": "16:25"
  },
  {
    "id": "pian-013",
    "direction": "incoming",
    "text": "Rantangnya udah gue anter ke apart. Ada lauk tambahan dari Papi, jangan diabisin sekali makan",
    "date": "2026-09-18",
    "time": "18:10"
  },
  {
    "id": "pian-014",
    "direction": "outgoing",
    "text": "Telat, gue udah makan dua kali",
    "date": "2026-09-18",
    "time": "18:12"
  },
  {
    "id": "pian-015",
    "direction": "incoming",
    "text": "Pantes pipi lu ga susut-susut",
    "date": "2026-09-18",
    "time": "18:14"
  },
  {
    "id": "pian-016",
    "direction": "outgoing",
    "text": "Sialan. Besok gue balikin rantangnya",
    "date": "2026-09-18",
    "time": "18:16"
  },
  {
    "id": "pian-017",
    "direction": "incoming",
    "text": "Qillllll.",
    "date": "2026-09-25",
    "time": "10:15"
  },
  {
    "id": "pian-018",
    "direction": "incoming",
    "text": "Lu dapet jatah libur kaga bulan depan? Temenin gue ke Bali yuk.",
    "date": "2026-09-25",
    "time": "10:15"
  },
  {
    "id": "pian-019",
    "direction": "outgoing",
    "text": "Males ah. Kerja. Lu kira gue pengangguran kayak temen-temen lu.",
    "date": "2026-09-25",
    "time": "12:20"
  },
  {
    "id": "pian-020",
    "direction": "incoming",
    "text": "Dih galak amat bos. Padahal mau gue bayarin tiket sama villa-nya.",
    "date": "2026-09-25",
    "time": "12:25"
  },
  {
    "id": "pian-021",
    "direction": "outgoing",
    "text": "Tanggal berapa emang? Gue liat jadwal studio dulu ntar.",
    "date": "2026-09-25",
    "time": "12:35"
  },
  {
    "id": "pian-022",
    "direction": "incoming",
    "text": "Tuh kan giliran dibayarin aja langsung nanya jadwal. Dasar adek matre lu wkwk.",
    "date": "2026-09-25",
    "time": "12:40"
  },
  {
    "id": "pian-023",
    "direction": "incoming",
    "text": "Tanggal Bali belum lu cek? Gue perlu booking kalau jadi",
    "date": "2026-09-25",
    "time": "13:00"
  },
  {
    "id": "pian-024",
    "direction": "outgoing",
    "text": "Belum ada kepastian jadwal, Bang. Jangan booking dulu",
    "date": "2026-09-25",
    "time": "13:06"
  },
  {
    "id": "pian-025",
    "direction": "incoming",
    "text": "Oke. Nanti kalau udah tau kabarin, gue fleksibel kok",
    "date": "2026-09-25",
    "time": "13:09"
  },
  {
    "id": "pian-026",
    "direction": "outgoing",
    "text": "Siap. Jangan mendadak juga, gue bukan karyawan lu",
    "date": "2026-09-25",
    "time": "13:11"
  },
  {
    "id": "pian-027",
    "direction": "incoming",
    "type": "voice",
    "duration": "0:08",
    "transcript": "Dek, lu lagi sama Panji ga? Ini temen gue ada yang mau nanya soal modif Harley, bengkel Panji nerima kan?",
    "date": "2026-10-02",
    "time": "19:00"
  },
  {
    "id": "pian-028",
    "direction": "outgoing",
    "text": "Nerima bang. Suruh temen lu dateng aja langsung ke bengkel, bilang dari lu biar diurusin anak buahnya.",
    "date": "2026-10-02",
    "time": "19:15"
  },
  {
    "id": "pian-029",
    "direction": "incoming",
    "text": "Oke sip.",
    "date": "2026-10-02",
    "time": "19:20"
  },
  {
    "id": "pian-030",
    "direction": "incoming",
    "text": "Temen gue udah kontak bengkel Panji buat Harley-nya. Katanya mau datang Jumat",
    "date": "2026-10-02",
    "time": "20:00"
  },
  {
    "id": "pian-031",
    "direction": "outgoing",
    "text": "Oke. Gue bilangin Panji biar anak-anak bengkel tau",
    "date": "2026-10-02",
    "time": "20:03"
  },
  {
    "id": "pian-032",
    "direction": "incoming",
    "text": "Sip. Kalau hasilnya bagus gue punya alasan buat promosiin bengkel mantu",
    "date": "2026-10-02",
    "time": "20:05"
  },
  {
    "id": "pian-033",
    "direction": "outgoing",
    "text": "Jangan panggil mantu depan dia, nanti kepalanya gede",
    "date": "2026-10-02",
    "time": "20:07"
  },
  {
    "id": "pian-034",
    "direction": "incoming",
    "type": "sticker",
    "mediaUrl": "/assets/stickers/pian_tired.png",
    "date": "2026-10-08",
    "time": "15:40"
  },
  {
    "id": "pian-035",
    "direction": "incoming",
    "text": "Lu kapan balik dah. Tolong bawa si Theo main ke luar ngapa.",
    "date": "2026-10-08",
    "time": "15:41"
  },
  {
    "id": "pian-036",
    "direction": "outgoing",
    "text": "Kenapa lagi tuh bocah satu?",
    "date": "2026-10-08",
    "time": "15:45"
  },
  {
    "id": "pian-037",
    "direction": "incoming",
    "text": "Meja kerja gue dicoret-coret pake spidol. Pusing gue ngadepinnya, mana tadi abis gue marahin malah nangis ngadu ke Papi.",
    "date": "2026-10-08",
    "time": "15:46"
  },
  {
    "id": "pian-038",
    "direction": "outgoing",
    "text": "Hahahaha rasain. Makanya jangan cuma dikunci biasa tuh pintu kamar, mending lu pasang gembok sekalian.",
    "date": "2026-10-08",
    "time": "15:50"
  },
  {
    "id": "pian-039",
    "direction": "incoming",
    "text": "Theo udah gue minta maaf tadi. Dia juga udah minta maaf soal meja",
    "date": "2026-10-08",
    "time": "16:20"
  },
  {
    "id": "pian-040",
    "direction": "outgoing",
    "text": "Bagus. Jangan galak-galak amat sama bocah, dia cuma kehabisan kertas",
    "date": "2026-10-08",
    "time": "16:23"
  },
  {
    "id": "pian-041",
    "direction": "incoming",
    "text": "Iya, gue juga salah tadi ngomongnya keras. Tapi meja itu susah dibersihin",
    "date": "2026-10-08",
    "time": "16:25"
  },
  {
    "id": "pian-042",
    "direction": "outgoing",
    "text": "Nanti gue bawain buku gambar sama kertas. Beres",
    "date": "2026-10-08",
    "time": "16:27"
  },
  {
    "id": "pian-043",
    "direction": "incoming",
    "text": "Gue baru bangun, muka gue masih item. Theo ketawa tiap lewat kamar",
    "date": "2026-10-11",
    "time": "15:00"
  },
  {
    "id": "pian-044",
    "direction": "outgoing",
    "text": "Foto dulu buat kenang-kenangan. Ntar ilang, lu kangen",
    "date": "2026-10-11",
    "time": "15:02"
  },
  {
    "id": "pian-045",
    "direction": "incoming",
    "text": "Lu belain Theo banget sekarang. Kemarin pas buku sketsa lu hampir dicoret, gue yang dimarahin",
    "date": "2026-10-11",
    "time": "15:04"
  },
  {
    "id": "pian-046",
    "direction": "outgoing",
    "text": "Karena lu emang paling gampang disuruh jagain barang",
    "date": "2026-10-11",
    "time": "15:06"
  },
  {
    "id": "pian-047",
    "direction": "incoming",
    "text": "Mochinya udah gue makan satu. Sisanya gue simpen buat nanti",
    "date": "2026-10-12",
    "time": "22:00"
  },
  {
    "id": "pian-048",
    "direction": "outgoing",
    "text": "Itu titipan Kenan, bukan buat lu semua",
    "date": "2026-10-12",
    "time": "22:02"
  },
  {
    "id": "pian-049",
    "direction": "incoming",
    "text": "Dia tadi udah makan. Jangan pelit sama abang sendiri",
    "date": "2026-10-12",
    "time": "22:04"
  },
  {
    "id": "pian-050",
    "direction": "outgoing",
    "text": "Pantes jadi anak tertua, logika lu selalu menguntungkan diri sendiri",
    "date": "2026-10-12",
    "time": "22:06"
  },
  {
    "id": "pian-051",
    "direction": "incoming",
    "text": "Qil, beneran tangan lu diinfus? Papi heboh banget neleponin gue tadi siang.",
    "date": "2026-10-20",
    "time": "19:20"
  },
  {
    "id": "pian-052",
    "direction": "outgoing",
    "text": "Cuma vitamin doang bang. Panji doang yg lebay pake di-story sgala.",
    "date": "2026-10-20",
    "time": "19:30"
  },
  {
    "id": "pian-053",
    "direction": "incoming",
    "text": "Makanya dengerin kata orang tua, jangan kerja mulu.",
    "date": "2026-10-20",
    "time": "19:32"
  },
  {
    "id": "pian-054",
    "direction": "incoming",
    "type": "sticker",
    "mediaUrl": "/assets/stickers/pian_laugh.png",
    "date": "2026-10-20",
    "time": "19:33"
  },
  {
    "id": "pian-055",
    "direction": "incoming",
    "text": "Gue denger lu udah makan dan istirahat. Bagus. Besok jangan langsung kerja full",
    "date": "2026-10-20",
    "time": "20:00"
  },
  {
    "id": "pian-056",
    "direction": "outgoing",
    "text": "Iya bang. Gua udah bilang ke kantor mau istirahat dulu",
    "date": "2026-10-20",
    "time": "20:03"
  },
  {
    "id": "pian-057",
    "direction": "incoming",
    "text": "Nah, gitu. Kalau butuh apa-apa kabarin",
    "date": "2026-10-20",
    "time": "20:05"
  },
  {
    "id": "pian-058",
    "direction": "outgoing",
    "text": "Siap, makasih",
    "date": "2026-10-20",
    "time": "20:07"
  },
  {
    "id": "pian-059",
    "direction": "incoming",
    "text": "Dek, gawat dek.",
    "date": "2026-10-27",
    "time": "13:05"
  },
  {
    "id": "pian-060",
    "direction": "incoming",
    "text": "Gue ga sengaja numpahin kopi ke karpet bulu kesayangan Papi.",
    "date": "2026-10-27",
    "time": "13:06"
  },
  {
    "id": "pian-061",
    "direction": "incoming",
    "type": "photo",
    "mediaUrl": "/assets/images/chats/pian_carpet_spill.jpg",
    "text": "Liat nih, nyerep banget anjir susah dilap.",
    "date": "2026-10-27",
    "time": "13:07"
  },
  {
    "id": "pian-062",
    "direction": "outgoing",
    "text": "Mampus. Tanggung sendiri akibatnya. Gue mau ngadu aja biar lu dicoret dari KK.",
    "date": "2026-10-27",
    "time": "13:30"
  },
  {
    "id": "pian-063",
    "direction": "incoming",
    "text": "Jahat bener lu jadi adek. Bantuin gue nutupin ntar kalo lu balik ke rumah.",
    "date": "2026-10-27",
    "time": "13:35"
  },
  {
    "id": "pian-064",
    "direction": "outgoing",
    "text": "Berapa lu mau bayar gue buat tutup mulut?",
    "date": "2026-10-27",
    "time": "13:40"
  },
  {
    "id": "pian-065",
    "direction": "incoming",
    "text": "Gocap.",
    "date": "2026-10-27",
    "time": "13:42"
  },
  {
    "id": "pian-066",
    "direction": "outgoing",
    "text": "Miskin. Selesaikan urusan lu sendiri sebagai anak tertua.",
    "date": "2026-10-27",
    "time": "13:45"
  },
  {
    "id": "pian-067",
    "direction": "outgoing",
    "text": "Bang, karpet Papi udah aman belum? Gue liat lu dari tadi online tapi ga berani buka grup",
    "date": "2026-10-27",
    "time": "14:00"
  },
  {
    "id": "pian-068",
    "direction": "incoming",
    "text": "Belum. Gue lagi coba bersihin, tapi noda kopinya udah nyerap banget",
    "date": "2026-10-27",
    "time": "14:03"
  },
  {
    "id": "pian-069",
    "direction": "outgoing",
    "text": "Wkwkwk kasian juga, tapi tanggung sendiri",
    "date": "2026-10-27",
    "time": "14:05"
  },
  {
    "id": "pian-070",
    "direction": "incoming",
    "text": "Lu jangan ikut-ikutan. Kalau Papi tau lu bantu nutupin, habis kita",
    "date": "2026-10-27",
    "time": "14:07"
  },
  {
    "id": "pian-071",
    "direction": "incoming",
    "text": "Woi.",
    "date": "2026-10-29",
    "time": "13:05"
  },
  {
    "id": "pian-072",
    "direction": "incoming",
    "text": "Gue liat mantan lu di Sency bawa gandengan baru anjir.",
    "date": "2026-10-29",
    "time": "13:12"
  },
  {
    "id": "pian-073",
    "direction": "outgoing",
    "text": "Ya terus? Biarin aja sih, gue udah sama Panji juga.",
    "date": "2026-10-29",
    "time": "13:20"
  },
  {
    "id": "pian-074",
    "direction": "incoming",
    "text": "Ya ngasih tau aja wkwkwk siapa tau lu kepo.",
    "date": "2026-10-29",
    "time": "13:22"
  },
  {
    "id": "pian-075",
    "direction": "outgoing",
    "text": "Kurang kerjaan banget lu ngegosip mulu pas jam kantor.",
    "date": "2026-10-29",
    "time": "13:30"
  },
  {
    "id": "pian-076",
    "direction": "incoming",
    "text": "Mantan lu yang kemarin gue liat itu ga penting. Gue cuma mau pastiin lu ga kepikiran",
    "date": "2026-10-29",
    "time": "13:32"
  },
  {
    "id": "pian-077",
    "direction": "outgoing",
    "text": "Engga, Bang. Beneran udah biasa aja. Gue malah lupa pernah pacaran sama dia",
    "date": "2026-10-29",
    "time": "13:35"
  },
  {
    "id": "pian-078",
    "direction": "incoming",
    "text": "Bagus. Jangan buang waktu buat yang udah lewat",
    "date": "2026-10-29",
    "time": "13:37"
  },
  {
    "id": "pian-079",
    "direction": "outgoing",
    "text": "Nasihat bijak dari orang yang kerjaannya jalan-jalan",
    "date": "2026-10-29",
    "time": "13:39"
  },
  {
    "id": "pian-080",
    "direction": "incoming",
    "text": "Papa bilang malam ini lu pulang. Jangan ngilang lagi",
    "date": "2026-10-29",
    "time": "17:30"
  },
  {
    "id": "pian-081",
    "direction": "outgoing",
    "text": "Kemarin juga pulang, Bang. Hari ini kalau ada waktu gue mampir",
    "date": "2026-10-29",
    "time": "17:33"
  },
  {
    "id": "pian-082",
    "direction": "incoming",
    "text": "Bagus. Theo udah nanya dari pagi",
    "date": "2026-10-29",
    "time": "17:35"
  }
];
