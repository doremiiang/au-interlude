export const ANTA_MESSAGES = [
  {
    "id": "anta-001",
    "direction": "incoming",
    "text": "Qil, nongkrong ayo. Gue bosen hidup.",
    "date": "2026-09-17",
    "time": "19:00"
  },
  {
    "id": "anta-002",
    "direction": "outgoing",
    "text": "Males. Nugas.",
    "date": "2026-09-17",
    "time": "19:15"
  },
  {
    "id": "anta-003",
    "direction": "incoming",
    "text": "Elah sok sibuk amat arsitek kita satu ini.",
    "date": "2026-09-17",
    "time": "19:16"
  },
  {
    "id": "anta-004",
    "direction": "outgoing",
    "text": "Emang sibuk. Lu kira gue pengangguran kayak lu.",
    "date": "2026-09-17",
    "time": "19:20"
  },
  {
    "id": "anta-005",
    "direction": "incoming",
    "text": "Sembarangan, gini-gini gue sibuk memperkaya diri.",
    "date": "2026-09-17",
    "time": "19:22"
  },
  {
    "id": "anta-006",
    "direction": "incoming",
    "text": "Jadi ga malam ini? Gue udah hampir ganti baju nih",
    "date": "2026-09-18",
    "time": "13:00"
  },
  {
    "id": "anta-007",
    "direction": "outgoing",
    "text": "Engga bisa, Ta. Deadline gue belum kelar. Besok aja kalau lu ga ada kerjaan",
    "date": "2026-09-18",
    "time": "13:05"
  },
  {
    "id": "anta-008",
    "direction": "incoming",
    "text": "Lu tuh hidupnya deadline mulu. Nanti gue kirim makanan biar ga makan angin",
    "date": "2026-09-18",
    "time": "13:07"
  },
  {
    "id": "anta-009",
    "direction": "outgoing",
    "text": "Ga usah. Simpen duit lu buat bayar kopi sendiri",
    "date": "2026-09-18",
    "time": "13:09"
  },
  {
    "id": "anta-010",
    "direction": "incoming",
    "type": "sticker",
    "mediaUrl": "/assets/stickers/anta_laugh.png",
    "date": "2026-09-25",
    "time": "10:00"
  },
  {
    "id": "anta-011",
    "direction": "incoming",
    "text": "Gue nemu foto komuk lu pas jaman SMP di pesbuk. Mau gue sebar ah.",
    "date": "2026-09-25",
    "time": "10:01"
  },
  {
    "id": "anta-012",
    "direction": "outgoing",
    "text": "Lu sebar beneran gue blokir nomer lu bangsat.",
    "date": "2026-09-25",
    "time": "10:15"
  },
  {
    "id": "anta-013",
    "direction": "incoming",
    "text": "Wkwkwk galak bener bos kita yang satu ini.",
    "date": "2026-09-25",
    "time": "10:17"
  },
  {
    "id": "anta-014",
    "direction": "incoming",
    "text": "Gue simpen foto SMP lu dulu ya. Buat arsip nasional",
    "date": "2026-09-25",
    "time": "10:30"
  },
  {
    "id": "anta-015",
    "direction": "outgoing",
    "text": "Hapus, Ta. Serius",
    "date": "2026-09-25",
    "time": "10:33"
  },
  {
    "id": "anta-016",
    "direction": "incoming",
    "text": "Wkwkwk yaudah. Tapi traktir gue sekali, baru gue pertimbangin",
    "date": "2026-09-25",
    "time": "10:35"
  },
  {
    "id": "anta-017",
    "direction": "outgoing",
    "text": "Pemerasan berkedok persahabatan",
    "date": "2026-09-25",
    "time": "10:37"
  },
  {
    "id": "anta-018",
    "direction": "incoming",
    "text": "Woy.",
    "date": "2026-10-02",
    "time": "12:30"
  },
  {
    "id": "anta-019",
    "direction": "incoming",
    "text": "Laki lu ngasih death glare ke si Dimas pas jemput lu di BSD kemaren? WKWKWK.",
    "date": "2026-10-02",
    "time": "12:31"
  },
  {
    "id": "anta-020",
    "direction": "outgoing",
    "text": "Dapet gosip dari mana lu anjir.",
    "date": "2026-10-02",
    "time": "12:35"
  },
  {
    "id": "anta-021",
    "direction": "incoming",
    "text": "Dimas kan temen futsal gue. Dia nanya ke gue kemaren, \"Ta, cowoknya Shaqil anak bengkel ya? Sangar bener diliatin gue pas nanya IG-nya.\"",
    "date": "2026-10-02",
    "time": "12:36"
  },
  {
    "id": "anta-022",
    "direction": "outgoing",
    "text": "Sumpah Panji lebay banget. Orang si Dimas nanya gara-gara mau tag foto site visit doang. Malu gue njir.",
    "date": "2026-10-02",
    "time": "12:40"
  },
  {
    "id": "anta-023",
    "direction": "incoming",
    "text": "Makanya pesona lu jangan ditebar-tebar boss, pawang lu posesif gitu.",
    "date": "2026-10-02",
    "time": "12:42"
  },
  {
    "id": "anta-024",
    "direction": "outgoing",
    "text": "Cot.",
    "date": "2026-10-02",
    "time": "12:45"
  },
  {
    "id": "anta-025",
    "direction": "incoming",
    "text": "Gue cuma mau tau, lu sama Panji aman kan setelah kejadian Dimas?",
    "date": "2026-10-02",
    "time": "12:50"
  },
  {
    "id": "anta-026",
    "direction": "outgoing",
    "text": "Aman. Paling dia cuma perlu diingetin jangan pasang muka mau makan orang",
    "date": "2026-10-02",
    "time": "12:53"
  },
  {
    "id": "anta-027",
    "direction": "incoming",
    "text": "Wkwk gue bilangin Dimas juga jangan sok akrab kalau belum kenal",
    "date": "2026-10-02",
    "time": "12:55"
  },
  {
    "id": "anta-028",
    "direction": "outgoing",
    "text": "Ga usah dibesar-besarin. Udah lewat",
    "date": "2026-10-02",
    "time": "12:57"
  },
  {
    "id": "anta-029",
    "direction": "incoming",
    "text": "Btw Dimas bilang makasih ya buat foto site visit kemarin. Katanya akhirnya bisa dia tag",
    "date": "2026-10-03",
    "time": "17:00"
  },
  {
    "id": "anta-030",
    "direction": "outgoing",
    "text": "Oh iya, gue lupa. Bilang sama-sama aja",
    "date": "2026-10-03",
    "time": "17:03"
  },
  {
    "id": "anta-031",
    "direction": "incoming",
    "text": "Dia juga bilang pacar lu serem tapi motornya keren",
    "date": "2026-10-03",
    "time": "17:05"
  },
  {
    "id": "anta-032",
    "direction": "outgoing",
    "text": "Fokusnya motor doang bagus",
    "date": "2026-10-03",
    "time": "17:07"
  },
  {
    "id": "anta-033",
    "direction": "incoming",
    "type": "call",
    "status": "missed",
    "date": "2026-10-15",
    "time": "20:00"
  },
  {
    "id": "anta-034",
    "direction": "incoming",
    "type": "call",
    "status": "missed",
    "date": "2026-10-15",
    "time": "20:01"
  },
  {
    "id": "anta-035",
    "direction": "incoming",
    "text": "Angkat woi.",
    "date": "2026-10-15",
    "time": "20:05"
  },
  {
    "id": "anta-036",
    "direction": "incoming",
    "text": "Gue mau nanya soal layout kamar, lu kan jago ginian.",
    "date": "2026-10-15",
    "time": "20:06"
  },
  {
    "id": "anta-037",
    "direction": "outgoing",
    "text": "Bawel. Gue lagi di jalan nyetir. Chat aja napa sih.",
    "date": "2026-10-15",
    "time": "20:30"
  },
  {
    "id": "anta-038",
    "direction": "incoming",
    "type": "photo",
    "mediaUrl": "/assets/images/chats/anta_room_layout.jpg",
    "text": "Kalo kasur gue pindah ke deket jendela bagus ga?",
    "date": "2026-10-15",
    "time": "20:32"
  },
  {
    "id": "anta-039",
    "direction": "outgoing",
    "text": "Gak. Kena tampias ujan ntar. Mending lu geser lemarinya ke sudut. Udah ah gue mau mandi, ntar gue gambarin kasarnya deh.",
    "date": "2026-10-15",
    "time": "20:45"
  },
  {
    "id": "anta-040",
    "direction": "incoming",
    "text": "Sayang banget deh gue sama sahabat gue yg galak ini 😘",
    "date": "2026-10-15",
    "time": "20:47"
  },
  {
    "id": "anta-041",
    "direction": "outgoing",
    "text": "Jijik njir.",
    "date": "2026-10-15",
    "time": "20:50"
  },
  {
    "id": "anta-042",
    "direction": "incoming",
    "text": "Gambaran kasar kamar gue udah lu kirim belum?",
    "date": "2026-10-16",
    "time": "18:00"
  },
  {
    "id": "anta-043",
    "direction": "outgoing",
    "text": "Belum. Gua baru sampe apart, mandi dulu. Nanti gua kirim",
    "date": "2026-10-16",
    "time": "18:03"
  },
  {
    "id": "anta-044",
    "direction": "incoming",
    "text": "Santai, jangan lupa aja. Gue pengen beresin sebelum akhir bulan",
    "date": "2026-10-16",
    "time": "18:05"
  },
  {
    "id": "anta-045",
    "direction": "outgoing",
    "text": "Iya. Dan jangan beli lemari baru sebelum gue liat ukuran kamarnya",
    "date": "2026-10-16",
    "time": "18:07"
  },
  {
    "id": "anta-046",
    "direction": "incoming",
    "text": "Oke, Pak Arsitek",
    "date": "2026-10-16",
    "time": "18:09"
  },
  {
    "id": "anta-047",
    "direction": "outgoing",
    "text": "Gue udah kirim sketsa kasarnya. Ukur ulang lebar jendela ya, jangan ngira-ngira",
    "date": "2026-10-17",
    "time": "10:00"
  },
  {
    "id": "anta-048",
    "direction": "incoming",
    "text": "Wih cepet juga. Oke besok gue ukur",
    "date": "2026-10-17",
    "time": "10:03"
  },
  {
    "id": "anta-049",
    "direction": "outgoing",
    "text": "Kalau udah, kirim ke gue. Jangan ditunda sampe tahun depan",
    "date": "2026-10-17",
    "time": "10:05"
  },
  {
    "id": "anta-050",
    "direction": "incoming",
    "text": "SIAP KAKAK ARSITEK",
    "date": "2026-10-17",
    "time": "10:07"
  },
  {
    "id": "anta-051",
    "direction": "incoming",
    "type": "sticker",
    "mediaUrl": "/assets/stickers/anta_mocking.png",
    "date": "2026-10-20",
    "time": "19:15"
  },
  {
    "id": "anta-052",
    "direction": "incoming",
    "text": "Cieee tipes. Gaya lu selangit sih kerjanya ngalahin kuda.",
    "date": "2026-10-20",
    "time": "19:16"
  },
  {
    "id": "anta-053",
    "direction": "outgoing",
    "text": "Bukan tipes anjir. Infus vitamin doang. Panji lebay pake di story segala.",
    "date": "2026-10-20",
    "time": "19:30"
  },
  {
    "id": "anta-054",
    "direction": "incoming",
    "type": "voice",
    "duration": "0:08",
    "transcript": "Halah ngeles aja lu. Bilang aja mau dimanjain sama pacar makanya pura-pura tumbang wkwkwk.",
    "date": "2026-10-20",
    "time": "19:32"
  },
  {
    "id": "anta-055",
    "direction": "outgoing",
    "text": "Sialan. Gue beneran kecapekan nyet. Keluarga gue di rumah juga pada heboh grgr story dia. Pusing kepala gue.",
    "date": "2026-10-20",
    "time": "19:35"
  },
  {
    "id": "anta-056",
    "direction": "incoming",
    "text": "HAHAHA mampus lu diomelin se-RT. Udah istirahat sana, ntar kapan-kapan gue jenguk bawa martabak.",
    "date": "2026-10-20",
    "time": "19:37"
  },
  {
    "id": "anta-057",
    "direction": "outgoing",
    "text": "Awas aja lu ga bawa beneran.",
    "date": "2026-10-20",
    "time": "19:40"
  },
  {
    "id": "anta-058",
    "direction": "incoming",
    "text": "Gue jadi jenguk lu Sabtu ya. Martabak udah gue pesen, jangan bilang ga mau",
    "date": "2026-10-22",
    "time": "18:30"
  },
  {
    "id": "anta-059",
    "direction": "outgoing",
    "text": "Gue ga bilang ga mau. Gue bilang jangan kebanyakan coklat",
    "date": "2026-10-22",
    "time": "18:33"
  },
  {
    "id": "anta-060",
    "direction": "incoming",
    "text": "Banyak maunya orang sakit",
    "date": "2026-10-22",
    "time": "18:35"
  },
  {
    "id": "anta-061",
    "direction": "outgoing",
    "text": "Kalau ga suka ya ga usah datang",
    "date": "2026-10-22",
    "time": "18:37"
  },
  {
    "id": "anta-062",
    "direction": "incoming",
    "text": "Lah diancem. Oke gue datang bawa yang keju aja",
    "date": "2026-10-22",
    "time": "18:39"
  },
  {
    "id": "anta-063",
    "direction": "incoming",
    "text": "Gue udah di lobi. Martabaknya masih anget, turun kalau udah siap",
    "date": "2026-10-24",
    "time": "17:00"
  },
  {
    "id": "anta-064",
    "direction": "outgoing",
    "text": "Iya, tunggu. Jangan lu habisin dulu",
    "date": "2026-10-24",
    "time": "17:03"
  },
  {
    "id": "anta-065",
    "direction": "incoming",
    "text": "Gue bukan Panji, tenang aja WKWK",
    "date": "2026-10-24",
    "time": "17:05"
  },
  {
    "id": "anta-066",
    "direction": "outgoing",
    "text": "Sok tau. Lima menit",
    "date": "2026-10-24",
    "time": "17:07"
  },
  {
    "id": "anta-067",
    "direction": "incoming",
    "text": "Qil, nongkrong ga ntar malem? Anak-anak pada mau ke Kopi Teras nih.",
    "date": "2026-10-29",
    "time": "14:00"
  },
  {
    "id": "anta-068",
    "direction": "outgoing",
    "text": "Ga bisa, gue disuruh Papa ikut makan keluarga malem ini. Kalo besok malem gmn?",
    "date": "2026-10-29",
    "time": "14:20"
  },
  {
    "id": "anta-069",
    "direction": "incoming",
    "text": "Boleh lah. Ajak Panji juga biar dia yang bayarin wkwk.",
    "date": "2026-10-29",
    "time": "14:22"
  },
  {
    "id": "anta-070",
    "direction": "outgoing",
    "text": "Matre lu miskin. Liat ntar deh.",
    "date": "2026-10-29",
    "time": "14:25"
  },
  {
    "id": "anta-071",
    "direction": "incoming",
    "text": "Besok jadi nongkrong sama anak-anak? Gue mau booking meja kalau jadi",
    "date": "2026-10-29",
    "time": "14:30"
  },
  {
    "id": "anta-072",
    "direction": "outgoing",
    "text": "Bisa kayaknya. Gue pulang dulu ke rumah, habis itu kabarin",
    "date": "2026-10-29",
    "time": "14:33"
  },
  {
    "id": "anta-073",
    "direction": "incoming",
    "text": "Oke. Panji ikut ya, biar gue bisa nagih traktiran",
    "date": "2026-10-29",
    "time": "14:35"
  },
  {
    "id": "anta-074",
    "direction": "outgoing",
    "text": "Matre lu konsisten banget",
    "date": "2026-10-29",
    "time": "14:37"
  },
  {
    "id": "anta-075",
    "direction": "incoming",
    "text": "Jadi malam ini jam berapa? Tempat biasa aja?",
    "date": "2026-10-30",
    "time": "17:00"
  },
  {
    "id": "anta-076",
    "direction": "outgoing",
    "text": "Gue kabarin lagi. Panji masih ada kerjaan, jangan booking dulu",
    "date": "2026-10-30",
    "time": "17:03"
  },
  {
    "id": "anta-077",
    "direction": "incoming",
    "text": "Siap. Tapi jangan batal mendadak, gue udah mandi",
    "date": "2026-10-30",
    "time": "17:05"
  }
];
