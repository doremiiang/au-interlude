export const JANUAR_MESSAGES = [
  {
    "id": "januar-001",
    "direction": "incoming",
    "text": "Woy bos arsitek!",
    "date": "2026-09-16",
    "time": "15:10"
  },
  {
    "id": "januar-002",
    "direction": "incoming",
    "type": "sticker",
    "mediaUrl": "/assets/stickers/januar_ teasing.png",
    "date": "2026-09-16",
    "time": "15:11"
  },
  {
    "id": "januar-003",
    "direction": "outgoing",
    "text": "Apaan lu sore-sore ngechat. Kurang kerjaan banget.",
    "date": "2026-09-16",
    "time": "15:25"
  },
  {
    "id": "januar-004",
    "direction": "incoming",
    "text": "Lagi nungguin Panji beres-beres bengkel nih. Capek banget seharian ngikutin bos besar ngomel mulu.",
    "date": "2026-09-16",
    "time": "15:28"
  },
  {
    "id": "januar-005",
    "direction": "outgoing",
    "text": "Makanya kerja yang bener, jangan malah ngajak ngobrol mulu anak buah lu.",
    "date": "2026-09-16",
    "time": "15:35"
  },
  {
    "id": "januar-006",
    "direction": "incoming",
    "text": "Wagelaseh galak bener pawangnya Panji wkwk.",
    "date": "2026-09-16",
    "time": "15:37"
  },
  {
    "id": "januar-007",
    "direction": "incoming",
    "text": "Qil, malem minggu ini lu, Panji, sama Marka ada acara ga? Temenin ngopi di Kopi Teras yuk.",
    "date": "2026-09-22",
    "time": "13:00"
  },
  {
    "id": "januar-008",
    "direction": "outgoing",
    "text": "Gue sih ngikut Panji ya, tapi kayaknya dia mau ngajak gue ke apart aja males keluar.",
    "date": "2026-09-22",
    "time": "13:15"
  },
  {
    "id": "januar-009",
    "direction": "incoming",
    "text": "Yaelah bucin mulu kerjanya dunia milik berdua. Sekali-kali gabung sama rakyat jelata.",
    "date": "2026-09-22",
    "time": "13:18"
  },
  {
    "id": "januar-010",
    "direction": "outgoing",
    "text": "Bawel lu. Ntar diconfir dulu sama Panji.",
    "date": "2026-09-22",
    "time": "13:20"
  },
  {
    "id": "januar-011",
    "direction": "incoming",
    "text": "Marka bilang kalau lu sama Panji jadi keluar, kabarin aja. Dia mau ikut kalau ga terlalu ramai",
    "date": "2026-09-22",
    "time": "13:25"
  },
  {
    "id": "januar-012",
    "direction": "outgoing",
    "text": "Gue tanya Panji dulu. Kalau ga jadi, jangan salahin gue",
    "date": "2026-09-22",
    "time": "13:28"
  },
  {
    "id": "januar-013",
    "direction": "incoming",
    "text": "Sip. Gue juga ga maksa, cuma pengen ketemu aja",
    "date": "2026-09-22",
    "time": "13:30"
  },
  {
    "id": "januar-014",
    "direction": "incoming",
    "text": "Qil... Sumpah ya hari ini mental gue kena banget di bengkel.",
    "date": "2026-09-28",
    "time": "11:10"
  },
  {
    "id": "januar-015",
    "direction": "incoming",
    "text": "Panji lagi mode singa kelaparan gara-gara klien minta bongkar ulang.",
    "date": "2026-09-28",
    "time": "11:11"
  },
  {
    "id": "januar-016",
    "direction": "outgoing",
    "text": "Hahaha sabar ya Nu. Marka tadi udah ngadu juga ke gue kalau lu ngebatin di bengkel.",
    "date": "2026-09-28",
    "time": "11:25"
  },
  {
    "id": "januar-017",
    "direction": "incoming",
    "text": "Tolong bilangin laki lu, jangan galak-galak amat, nanti gantengnya luntur.",
    "date": "2026-09-28",
    "time": "11:28"
  },
  {
    "id": "januar-018",
    "direction": "outgoing",
    "text": "Udah ditenangin kok. Tenang aja ntar siang gue bawain nasi padang buat kalian biar pada anteng.",
    "date": "2026-09-28",
    "time": "11:30"
  },
  {
    "id": "januar-019",
    "direction": "incoming",
    "text": "WAAAANJIR THE BEST EMANG PACAR TEMEN GUE!",
    "date": "2026-09-28",
    "time": "11:32"
  },
  {
    "id": "januar-020",
    "direction": "incoming",
    "text": "Nasi padang lu kemarin sukses bikin suasana bengkel damai. Anak-anak masih ngomongin",
    "date": "2026-09-28",
    "time": "12:00"
  },
  {
    "id": "januar-021",
    "direction": "outgoing",
    "text": "Bagus. Lain kali lu yang bawa, jangan numpang kenyang terus",
    "date": "2026-09-28",
    "time": "12:03"
  },
  {
    "id": "januar-022",
    "direction": "incoming",
    "text": "Gue mah siap. Tapi budget gue cuma buat kerupuk",
    "date": "2026-09-28",
    "time": "12:05"
  },
  {
    "id": "januar-023",
    "direction": "outgoing",
    "text": "Pantes Panji gaji lu kecil",
    "date": "2026-09-28",
    "time": "12:07"
  },
  {
    "id": "januar-024",
    "direction": "incoming",
    "text": "Bos, besok jadi ikut Panji ke toko bahan kulit? Gue mau titip lihat sarung tangan baru",
    "date": "2026-10-09",
    "time": "20:00"
  },
  {
    "id": "januar-025",
    "direction": "outgoing",
    "text": "Kayaknya gue ikut sebentar. Lu titip ukuran apa?",
    "date": "2026-10-09",
    "time": "20:03"
  },
  {
    "id": "januar-026",
    "direction": "incoming",
    "text": "Yang L. Jangan salah beli, nanti tangan gue kayak anak kecil",
    "date": "2026-10-09",
    "time": "20:05"
  },
  {
    "id": "januar-027",
    "direction": "incoming",
    "type": "photo",
    "mediaUrl": "/assets/images/chats/januar_shoes.jpg",
    "text": "Liat nih Qil, dibeliin sepatu sama Marka gara-gara dia bilang muka gue melas mulu minggu ini wkwk.",
    "date": "2026-10-12",
    "time": "15:00"
  },
  {
    "id": "januar-028",
    "direction": "outgoing",
    "text": "Hoki banget emang lu dipelihara sama Marka.",
    "date": "2026-10-12",
    "time": "15:15"
  },
  {
    "id": "januar-029",
    "direction": "incoming",
    "text": "Iri bilang boss 😎 Makanya suruh Panji beliin juga.",
    "date": "2026-10-12",
    "time": "15:18"
  },
  {
    "id": "januar-030",
    "direction": "outgoing",
    "text": "Ogah, duit-duit gue sendiri.",
    "date": "2026-10-12",
    "time": "15:20"
  },
  {
    "id": "januar-031",
    "direction": "incoming",
    "text": "Sepatunya udah gue pake. Marka bilang cocok, berarti dia ga nyesel beliin",
    "date": "2026-10-12",
    "time": "15:30"
  },
  {
    "id": "januar-032",
    "direction": "outgoing",
    "text": "Ya jelas cocok, gue yang kasih tau merknya",
    "date": "2026-10-12",
    "time": "15:33"
  },
  {
    "id": "januar-033",
    "direction": "incoming",
    "text": "Jangan sombong dulu. Dia yang bayar, bukan lu",
    "date": "2026-10-12",
    "time": "15:35"
  },
  {
    "id": "januar-034",
    "direction": "incoming",
    "type": "call",
    "status": "missed",
    "date": "2026-10-20",
    "time": "19:15"
  },
  {
    "id": "januar-035",
    "direction": "incoming",
    "text": "Qil! Lu beneran sakit opname di RS gara-gara tipes?",
    "date": "2026-10-20",
    "time": "19:16"
  },
  {
    "id": "januar-036",
    "direction": "incoming",
    "text": "Gue sama Marka mau langsung meluncur ke sana nih bawain buah sama bubur.",
    "date": "2026-10-20",
    "time": "19:17"
  },
  {
    "id": "januar-037",
    "direction": "outgoing",
    "text": "Buset pada heboh banget padahal cuma diinfus vitamin doang! Gausah ke sini, gue di apartemen dan udah beres.",
    "date": "2026-10-20",
    "time": "19:25"
  },
  {
    "id": "januar-038",
    "direction": "incoming",
    "type": "voice",
    "duration": "0:09",
    "transcript": "Yah dilarang padahal gue mau numpang makan malam gratis di apart lu. Yaudah cepet sembuh ya bos.",
    "date": "2026-10-20",
    "time": "19:28"
  },
  {
    "id": "januar-039",
    "direction": "outgoing",
    "text": "Modus doang lu numpang makan. Pulang sana ke kosan Marka.",
    "date": "2026-10-20",
    "time": "19:32"
  },
  {
    "id": "januar-040",
    "direction": "incoming",
    "text": "Gue tadi mau jenguk lu, tapi Marka bilang jangan ganggu kalau lu masih istirahat",
    "date": "2026-10-20",
    "time": "19:45"
  },
  {
    "id": "januar-041",
    "direction": "outgoing",
    "text": "Bener. Gue udah enakan, tapi belum pengen nerima rombongan",
    "date": "2026-10-20",
    "time": "19:48"
  },
  {
    "id": "januar-042",
    "direction": "incoming",
    "text": "Oke, gua tahan diri. Besok-besok kalau udah fit kita makan",
    "date": "2026-10-20",
    "time": "19:50"
  },
  {
    "id": "januar-043",
    "direction": "incoming",
    "text": "Qil, lu jadi survei ke BSD hari ini?",
    "date": "2026-10-28",
    "time": "12:00"
  },
  {
    "id": "januar-044",
    "direction": "outgoing",
    "text": "Jadi, ini lagi di jalan. Kenapa nu?",
    "date": "2026-10-28",
    "time": "12:15"
  },
  {
    "id": "januar-045",
    "direction": "incoming",
    "text": "Titip dimsum dong yang di PIK, ntar gue transfer duitnya plus ongkir.",
    "date": "2026-10-28",
    "time": "12:18"
  },
  {
    "id": "januar-046",
    "direction": "outgoing",
    "text": "Jauh banget anjir rute gue ga kesana. Pesen ojol sendiri aja ribet bgt.",
    "date": "2026-10-28",
    "time": "12:20"
  },
  {
    "id": "januar-047",
    "direction": "incoming",
    "text": "Yaelah pelit amat sama temen sendiri. Dihukum Panji baru tau rasa lu wkwk.",
    "date": "2026-10-28",
    "time": "12:22"
  },
  {
    "id": "januar-048",
    "direction": "outgoing",
    "text": "Bacot.",
    "date": "2026-10-28",
    "time": "12:25"
  },
  {
    "id": "januar-049",
    "direction": "incoming",
    "text": "Dimsumnya jadi lu ga ambil ya? Marka bilang dia udah beliin, gue tinggal ambil di rumah",
    "date": "2026-10-28",
    "time": "12:30"
  },
  {
    "id": "januar-050",
    "direction": "outgoing",
    "text": "Nah gitu dong, ada yang bisa mikir rute",
    "date": "2026-10-28",
    "time": "12:33"
  },
  {
    "id": "januar-051",
    "direction": "incoming",
    "text": "Tapi gue tetep minta jatah satu box kalau ketemu",
    "date": "2026-10-28",
    "time": "12:35"
  },
  {
    "id": "januar-052",
    "direction": "incoming",
    "text": "Besok malam kalau nongkrong kabarin. Gue ga mau ketinggalan lagi",
    "date": "2026-10-29",
    "time": "17:15"
  },
  {
    "id": "januar-053",
    "direction": "outgoing",
    "text": "Belum pasti, Nu. Jangan bikin jadwal sendiri dulu",
    "date": "2026-10-29",
    "time": "17:18"
  },
  {
    "id": "januar-054",
    "direction": "incoming",
    "text": "Oke bos. Gue tunggu komando",
    "date": "2026-10-29",
    "time": "17:20"
  }
];
