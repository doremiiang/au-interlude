export const MARKA_MESSAGES = [
  {
    "id": "marka-001",
    "direction": "incoming",
    "text": "Qil, lu lagi sibuk ga?",
    "date": "2026-09-18",
    "time": "12:10"
  },
  {
    "id": "marka-002",
    "direction": "outgoing",
    "text": "Ngga terlalu. Kenapa Mar?",
    "date": "2026-09-18",
    "time": "12:35"
  },
  {
    "id": "marka-003",
    "direction": "incoming",
    "text": "Mau nanya sepatu yg diincer Januar pas kalian jalan kemaren merk apa ya? Lupa gue.",
    "date": "2026-09-18",
    "time": "12:37"
  },
  {
    "id": "marka-004",
    "direction": "outgoing",
    "text": "Oh yg putih itu? New Balance 550. Tumben lu beliin, ultahnya masih lama kan?",
    "date": "2026-09-18",
    "time": "12:40"
  },
  {
    "id": "marka-005",
    "direction": "incoming",
    "text": "Buat ngeredain rewelnya aja. Dia ngeluh capek mulu di bengkel minggu ini. Thanks Qil.",
    "date": "2026-09-18",
    "time": "12:42"
  },
  {
    "id": "marka-006",
    "direction": "outgoing",
    "text": "Sip. Emang lu doang pawangnya wkwk.",
    "date": "2026-09-18",
    "time": "12:45"
  },
  {
    "id": "marka-007",
    "direction": "incoming",
    "text": "Gue udah pesen sepatunya. Makasih ya udah bantu cari model yang dia suka",
    "date": "2026-09-18",
    "time": "12:50"
  },
  {
    "id": "marka-008",
    "direction": "outgoing",
    "text": "Sama-sama. Jangan kasih tau dulu, biar dia kaget",
    "date": "2026-09-18",
    "time": "12:53"
  },
  {
    "id": "marka-009",
    "direction": "incoming",
    "text": "Iya. Dia kalau dikasih kejutan malah banyak komentar dulu",
    "date": "2026-09-18",
    "time": "12:55"
  },
  {
    "id": "marka-010",
    "direction": "outgoing",
    "text": "Itu bahasa halus dari cerewet",
    "date": "2026-09-18",
    "time": "12:57"
  },
  {
    "id": "marka-011",
    "direction": "incoming",
    "type": "photo",
    "mediaUrl": "/assets/images/chats/marka_sleeping_cat.jpg",
    "text": "Kucingnya mirip lu pas lagi tepar ngerjain maket.",
    "date": "2026-09-24",
    "time": "16:15"
  },
  {
    "id": "marka-012",
    "direction": "outgoing",
    "text": "Kurang ajar. Di mana lu?",
    "date": "2026-09-24",
    "time": "16:20"
  },
  {
    "id": "marka-013",
    "direction": "incoming",
    "text": "Kopi Teras. Lagi nungguin Januar cukur rambut di barbershop sebelah.",
    "date": "2026-09-24",
    "time": "16:22"
  },
  {
    "id": "marka-014",
    "direction": "outgoing",
    "text": "Pantes lu gabut. Jangan lupa traktir temen gue ntar abis cukur.",
    "date": "2026-09-24",
    "time": "16:25"
  },
  {
    "id": "marka-015",
    "direction": "incoming",
    "text": "Udah pulang. Januar tadi potong rambutnya kependekan, sekarang nyalahin tukang cukur",
    "date": "2026-09-24",
    "time": "17:00"
  },
  {
    "id": "marka-016",
    "direction": "outgoing",
    "text": "Wkwk padahal dia yang minta pendek",
    "date": "2026-09-24",
    "time": "17:03"
  },
  {
    "id": "marka-017",
    "direction": "incoming",
    "text": "Iya. Gue cuma ngangguk dari tadi biar dia puas ngomel",
    "date": "2026-09-24",
    "time": "17:05"
  },
  {
    "id": "marka-018",
    "direction": "incoming",
    "text": "Qil.",
    "date": "2026-09-28",
    "time": "11:05"
  },
  {
    "id": "marka-019",
    "direction": "incoming",
    "text": "Laki lu kenapa dah? Januar ngebatin banget pagi ini di bengkel, katanya bos Panji lagi mode senggol bacok.",
    "date": "2026-09-28",
    "time": "11:06"
  },
  {
    "id": "marka-020",
    "direction": "outgoing",
    "text": "Hahaha iya kliennya rewel minta bongkar ulang padahal udah deal. Sorry ya cowok lu kena imbasnya.",
    "date": "2026-09-28",
    "time": "11:20"
  },
  {
    "id": "marka-021",
    "direction": "incoming",
    "type": "sticker",
    "mediaUrl": "/assets/stickers/marka_sigh.png",
    "date": "2026-09-28",
    "time": "11:22"
  },
  {
    "id": "marka-022",
    "direction": "incoming",
    "text": "Kudu dikasih makan enak tuh si bos biar ga tantrum.",
    "date": "2026-09-28",
    "time": "11:23"
  },
  {
    "id": "marka-023",
    "direction": "outgoing",
    "text": "Aman. Ini gue lagi pesen nasi padang buat dibawa ke bengkel. Ntar gue bawain juga buat Januar deh sebagai kompensasi kupingnya panas.",
    "date": "2026-09-28",
    "time": "11:25"
  },
  {
    "id": "marka-024",
    "direction": "incoming",
    "text": "Mantap. Hati-hati lu nyetirnya.",
    "date": "2026-09-28",
    "time": "11:26"
  },
  {
    "id": "marka-025",
    "direction": "incoming",
    "text": "Sekarang Panji udah mendingan. Januar tadi minta maaf ke anak bengkel karena sempet ikut kena omel",
    "date": "2026-09-28",
    "time": "11:30"
  },
  {
    "id": "marka-026",
    "direction": "outgoing",
    "text": "Bagus deh. Panji juga lagi banyak pikiran karena kliennya",
    "date": "2026-09-28",
    "time": "11:33"
  },
  {
    "id": "marka-027",
    "direction": "incoming",
    "text": "Iya, gue ngerti. Nanti kalau dia pulang gue ajak makan dulu biar ga kebawa suasana kerja",
    "date": "2026-09-28",
    "time": "11:35"
  },
  {
    "id": "marka-028",
    "direction": "outgoing",
    "text": "Makasih ya udah sabar sama dia",
    "date": "2026-09-28",
    "time": "11:37"
  },
  {
    "id": "marka-029",
    "direction": "incoming",
    "type": "call",
    "status": "missed",
    "date": "2026-10-10",
    "time": "19:30"
  },
  {
    "id": "marka-030",
    "direction": "incoming",
    "text": "Qil, Januar sama lu ga malem ini?",
    "date": "2026-10-10",
    "time": "19:31"
  },
  {
    "id": "marka-031",
    "direction": "outgoing",
    "text": "Engga, gue lagi di apart rebahan. Kenapa? Hapenya ga aktif ya?",
    "date": "2026-10-10",
    "time": "19:40"
  },
  {
    "id": "marka-032",
    "direction": "incoming",
    "text": "Iya. Tadi pamitnya mau beli rokok bentar ke depan tapi hapenya ketinggalan di kosan gue. Udah sejam ga balik.",
    "date": "2026-10-10",
    "time": "19:42"
  },
  {
    "id": "marka-033",
    "direction": "incoming",
    "type": "voice",
    "duration": "0:07",
    "transcript": "Eh sorry Qil gausah dicari, ini anaknya baru balik. Nyasar ngobrol sama kang nasgor ternyata dia.",
    "date": "2026-10-10",
    "time": "19:55"
  },
  {
    "id": "marka-034",
    "direction": "outgoing",
    "text": "Wkwkwk emang random banget tuh anak heran gue. Yaudah aman.",
    "date": "2026-10-10",
    "time": "20:00"
  },
  {
    "id": "marka-035",
    "direction": "incoming",
    "text": "Gue tadi nemu hapenya di bawah bantal. Ternyata dia bawa pulang rokok doang, bukan hape",
    "date": "2026-10-10",
    "time": "20:05"
  },
  {
    "id": "marka-036",
    "direction": "outgoing",
    "text": "Hahaha. Yang penting udah ketemu orangnya",
    "date": "2026-10-10",
    "time": "20:08"
  },
  {
    "id": "marka-037",
    "direction": "incoming",
    "text": "Iya. Dia sekarang lagi makan, tadi katanya lupa makan siang",
    "date": "2026-10-10",
    "time": "20:10"
  },
  {
    "id": "marka-038",
    "direction": "incoming",
    "text": "Qil, lu sakit?",
    "date": "2026-10-20",
    "time": "19:25"
  },
  {
    "id": "marka-039",
    "direction": "incoming",
    "text": "Liat IG story Panji tadi lu diinfus. Januar langsung heboh mau jenguk lu ke apart sekarang.",
    "date": "2026-10-20",
    "time": "19:26"
  },
  {
    "id": "marka-040",
    "direction": "outgoing",
    "text": "Astaga, gausah! Cuma infus vitamin Mar biar ga tipes. Panji doang emang lebay difotoin sgala. Tahan tuh cowok lu jangan suruh ke sini.",
    "date": "2026-10-20",
    "time": "19:35"
  },
  {
    "id": "marka-041",
    "direction": "incoming",
    "text": "Udah gue tahan anaknya. Lagian lu juga sih, dibilangin jangan nembus batas limit kalo kerja.",
    "date": "2026-10-20",
    "time": "19:37"
  },
  {
    "id": "marka-042",
    "direction": "outgoing",
    "text": "Iya iya maaf Bapak Marka. Ntar bilangin Januar gue gapapa ya, besok juga udah bisa nongkrong.",
    "date": "2026-10-20",
    "time": "19:40"
  },
  {
    "id": "marka-043",
    "direction": "incoming",
    "text": "Siap. Istirahat Qil.",
    "date": "2026-10-20",
    "time": "19:42"
  },
  {
    "id": "marka-044",
    "direction": "incoming",
    "text": "Januar masih kepikiran mau jenguk lu. Gue bilang tunggu sampai lu beneran enakan",
    "date": "2026-10-20",
    "time": "20:00"
  },
  {
    "id": "marka-045",
    "direction": "outgoing",
    "text": "Makasih ya. Bilangin dia ga perlu bawa apa-apa, gue udah ada makanan",
    "date": "2026-10-20",
    "time": "20:03"
  },
  {
    "id": "marka-046",
    "direction": "incoming",
    "text": "Siap. Nanti kalau udah fit kita ketemu rame-rame aja",
    "date": "2026-10-20",
    "time": "20:05"
  },
  {
    "id": "marka-047",
    "direction": "incoming",
    "text": "Qil, lu jadi ke BSD kan ini hari survei?",
    "date": "2026-10-28",
    "time": "12:15"
  },
  {
    "id": "marka-048",
    "direction": "outgoing",
    "text": "Jadi, ini lagi di jalan. Kenapa?",
    "date": "2026-10-28",
    "time": "12:30"
  },
  {
    "id": "marka-049",
    "direction": "incoming",
    "text": "Januar nitip nanya, lu pulangnya lewat PIK ga ntar sore? Dia mau nitip dimsum yang deket situ katanya.",
    "date": "2026-10-28",
    "time": "12:32"
  },
  {
    "id": "marka-050",
    "direction": "outgoing",
    "text": "Jauh gila. Gak mau gue. Suruh dia pesen ojol aja kenapa sih.",
    "date": "2026-10-28",
    "time": "12:35"
  },
  {
    "id": "marka-051",
    "direction": "incoming",
    "text": "Wkwkwk udah gue tebak pasti lu nolak. Biar gue aja ntar yang beliin buat dia. Semangat surveinya.",
    "date": "2026-10-28",
    "time": "12:40"
  },
  {
    "id": "marka-052",
    "direction": "outgoing",
    "text": "Thanks Mar. Emang lu doang yang sabar ngadepin dia 😭",
    "date": "2026-10-28",
    "time": "12:45"
  },
  {
    "id": "marka-053",
    "direction": "incoming",
    "text": "Dimsum yang dia mau udah gue ambil. Dia tadi seneng banget, katanya lu akhirnya punya penolakan yang konsisten",
    "date": "2026-10-28",
    "time": "12:50"
  },
  {
    "id": "marka-054",
    "direction": "outgoing",
    "text": "Wkwk bilangin makasih. Gue ga mau muter jauh cuma buat dimsum",
    "date": "2026-10-28",
    "time": "12:53"
  },
  {
    "id": "marka-055",
    "direction": "incoming",
    "text": "Udah gue bilang. Dia juga nitip salam",
    "date": "2026-10-28",
    "time": "12:55"
  },
  {
    "id": "marka-056",
    "direction": "incoming",
    "text": "Jangan lupa istirahat setelah survei hari ini. Cuacanya panas",
    "date": "2026-10-30",
    "time": "15:00"
  },
  {
    "id": "marka-057",
    "direction": "outgoing",
    "text": "Siap, Marka. Tadi udah minum banyak kok",
    "date": "2026-10-30",
    "time": "15:03"
  },
  {
    "id": "marka-058",
    "direction": "incoming",
    "text": "Bagus. Kalau butuh dimsum, kali ini gue yang antar",
    "date": "2026-10-30",
    "time": "15:05"
  }
];
