export const ESTA_MESSAGES = [
  {
    "id": "esta-001",
    "direction": "outgoing",
    "text": "Bang, lu ada di rumah ga?",
    "date": "2026-09-21",
    "time": "19:10"
  },
  {
    "id": "esta-002",
    "direction": "incoming",
    "text": "Ada nih di kamar. Kenapa dek? Tumben nyariin.",
    "date": "2026-09-21",
    "time": "19:25"
  },
  {
    "id": "esta-003",
    "direction": "outgoing",
    "text": "Cariin charger laptop gue dong, kayaknya ketinggalan di meja makan pas balik weekend kemarin.",
    "date": "2026-09-21",
    "time": "19:26"
  },
  {
    "id": "esta-004",
    "direction": "incoming",
    "text": "Bentar gue cek ke bawah.",
    "date": "2026-09-21",
    "time": "19:35"
  },
  {
    "id": "esta-005",
    "direction": "incoming",
    "text": "Ada nih disimpen Bi Inah. Mau gue kirim pake Gojek apa lu ambil sendiri?",
    "date": "2026-09-21",
    "time": "19:40"
  },
  {
    "id": "esta-006",
    "direction": "outgoing",
    "text": "Gojekin aja bang. Males ke rumah, gue lagi dikejar deadline maket.",
    "date": "2026-09-21",
    "time": "19:42"
  },
  {
    "id": "esta-007",
    "direction": "incoming",
    "text": "Sip, nanti gue pesan kurirnya. Jangan keseringan ngelembur, muka lu pucet pas terakhir ke sini.",
    "date": "2026-09-21",
    "time": "19:45"
  },
  {
    "id": "esta-008",
    "direction": "outgoing",
    "text": "Iya bawel. Thanks ya bang.",
    "date": "2026-09-21",
    "time": "19:46"
  },
  {
    "id": "esta-009",
    "direction": "incoming",
    "text": "Paket charger lu udah gue kirim. Kurirnya bilang 20 menit",
    "date": "2026-09-21",
    "time": "20:05"
  },
  {
    "id": "esta-010",
    "direction": "outgoing",
    "text": "Oke bang. Makasih banget, nyawa laptop gue tertolong",
    "date": "2026-09-21",
    "time": "20:08"
  },
  {
    "id": "esta-011",
    "direction": "incoming",
    "text": "Laptop doang yang nyawa, yang punya jangan sampai tumbang",
    "date": "2026-09-21",
    "time": "20:10"
  },
  {
    "id": "esta-012",
    "direction": "outgoing",
    "text": "Iya, Bang Esta",
    "date": "2026-09-21",
    "time": "20:12"
  },
  {
    "id": "esta-013",
    "direction": "incoming",
    "text": "Jangan jawab iya doang kalau ujung-ujungnya begadang",
    "date": "2026-09-21",
    "time": "20:14"
  },
  {
    "id": "esta-014",
    "direction": "incoming",
    "text": "Btw Papa udah bisa buka Facebook lagi belum?",
    "date": "2026-09-22",
    "time": "20:00"
  },
  {
    "id": "esta-015",
    "direction": "outgoing",
    "text": "Udah bang. Tadi Shaqil benerin pas mampir, cuma kepencet bahasa",
    "date": "2026-09-22",
    "time": "20:04"
  },
  {
    "id": "esta-016",
    "direction": "incoming",
    "text": "Syukur. Dia tadi nanya gue tombol buat upload foto di mana, gue pura-pura ga tau wkwk",
    "date": "2026-09-22",
    "time": "20:06"
  },
  {
    "id": "esta-017",
    "direction": "outgoing",
    "text": "Jahat banget lu sama bapak sendiri",
    "date": "2026-09-22",
    "time": "20:08"
  },
  {
    "id": "esta-018",
    "direction": "incoming",
    "text": "Biar dia belajar pelan-pelan. Kalau gue ajarin, besok-besok semua disuruh gue",
    "date": "2026-09-22",
    "time": "20:10"
  },
  {
    "id": "esta-019",
    "direction": "incoming",
    "text": "Dek, Panji ntar malem ikut makan di rumah ga?",
    "date": "2026-09-27",
    "time": "16:10"
  },
  {
    "id": "esta-020",
    "direction": "outgoing",
    "text": "Gatau deh bang, dia lagi repot di bengkel kayaknya. Ntar gue tanyain.",
    "date": "2026-09-27",
    "time": "16:45"
  },
  {
    "id": "esta-021",
    "direction": "incoming",
    "text": "Oke. Kata Papi kalo dia ikut, mau dimasakin rendang ayam kesukaannya.",
    "date": "2026-09-27",
    "time": "16:46"
  },
  {
    "id": "esta-022",
    "direction": "outgoing",
    "text": "Wah disayang banget calon menantu satu itu wkwk.",
    "date": "2026-09-27",
    "time": "16:50"
  },
  {
    "id": "esta-023",
    "direction": "incoming",
    "text": "Yaiyalah daripada lu, kerjaannya ngerepotin mulu.",
    "date": "2026-09-27",
    "time": "16:52"
  },
  {
    "id": "esta-024",
    "direction": "outgoing",
    "text": "Bang, Panji bilang mau mampir habis tutup bengkel. Kalau Papi masih masak bilangin jangan nungguin",
    "date": "2026-09-27",
    "time": "17:00"
  },
  {
    "id": "esta-025",
    "direction": "incoming",
    "text": "Gue kabarin. Papi pasti malah nambah lauk kalau tau dia datang",
    "date": "2026-09-27",
    "time": "17:03"
  },
  {
    "id": "esta-026",
    "direction": "outgoing",
    "text": "Nah itu. Nanti rendangnya habis sebelum gue kebagian",
    "date": "2026-09-27",
    "time": "17:05"
  },
  {
    "id": "esta-027",
    "direction": "incoming",
    "text": "Lu mah selalu mikirin jatah makan sendiri",
    "date": "2026-09-27",
    "time": "17:07"
  },
  {
    "id": "esta-028",
    "direction": "outgoing",
    "text": "Prioritas hidup harus jelas bang",
    "date": "2026-09-27",
    "time": "17:09"
  },
  {
    "id": "esta-029",
    "direction": "incoming",
    "text": "Bang, lu ada pinjaman buku referensi arsitektur nggak yang modern minimalis?",
    "date": "2026-10-05",
    "time": "20:00"
  },
  {
    "id": "esta-030",
    "direction": "outgoing",
    "text": "Ada, yang sampul abu-abu kan? Mau lu pinjem buat tender?",
    "date": "2026-10-05",
    "time": "20:15"
  },
  {
    "id": "esta-031",
    "direction": "incoming",
    "text": "Iya betul. Besok kalau gue main ke apart lu, gue ambil ya.",
    "date": "2026-10-05",
    "time": "20:20"
  },
  {
    "id": "esta-032",
    "direction": "outgoing",
    "text": "Yaudah ambilin aja, tapi jangan lupa balikin ya, jangan kaya barang-barang lain suka disimpen seabad.",
    "date": "2026-10-05",
    "time": "20:25"
  },
  {
    "id": "esta-033",
    "direction": "incoming",
    "text": "Iya santai.",
    "date": "2026-10-05",
    "time": "20:26"
  },
  {
    "id": "esta-034",
    "direction": "outgoing",
    "text": "Buku sampul abu-abu yang abang pinjem itu gue taro di rak paling bawah ya",
    "date": "2026-10-06",
    "time": "18:30"
  },
  {
    "id": "esta-035",
    "direction": "incoming",
    "text": "Oke, besok gue ambil sekalian pas lewat area apart lu",
    "date": "2026-10-06",
    "time": "18:33"
  },
  {
    "id": "esta-036",
    "direction": "outgoing",
    "text": "Jangan lupa dibawa pulang lagi. Gue masih butuh buat referensi",
    "date": "2026-10-06",
    "time": "18:35"
  },
  {
    "id": "esta-037",
    "direction": "incoming",
    "text": "Santai. Gue pinjem, bukan adopsi",
    "date": "2026-10-06",
    "time": "18:37"
  },
  {
    "id": "esta-038",
    "direction": "incoming",
    "text": "Papi jadi pilih maroon. Papa masih ngotot mustard sampai tadi pagi",
    "date": "2026-10-13",
    "time": "16:20"
  },
  {
    "id": "esta-039",
    "direction": "outgoing",
    "text": "Untung Papi punya selera sendiri",
    "date": "2026-10-13",
    "time": "16:22"
  },
  {
    "id": "esta-040",
    "direction": "incoming",
    "text": "Papa akhirnya nyerah setelah Kenan bilang kayak seragam parkir",
    "date": "2026-10-13",
    "time": "16:24"
  },
  {
    "id": "esta-041",
    "direction": "outgoing",
    "text": "WKWK anak itu mulutnya ga ada rem",
    "date": "2026-10-13",
    "time": "16:26"
  },
  {
    "id": "esta-042",
    "direction": "incoming",
    "text": "Dek. Adeknya Panji nanyain lu suka makanan manis ga?",
    "date": "2026-10-18",
    "time": "11:20"
  },
  {
    "id": "esta-043",
    "direction": "outgoing",
    "text": "Gue mah bebas. Suruh bawain matcha aja bang, gue doyan.",
    "date": "2026-10-18",
    "time": "11:25"
  },
  {
    "id": "esta-044",
    "direction": "incoming",
    "text": "Oke. Ini bocahnya lagi deg-degan mau ke rumah, takut diinterogasi Papa.",
    "date": "2026-10-18",
    "time": "11:30"
  },
  {
    "id": "esta-045",
    "direction": "outgoing",
    "text": "Halah bilangin gausah takut. Papa mah asik asal disogok makanan.",
    "date": "2026-10-18",
    "time": "11:35"
  },
  {
    "id": "esta-046",
    "direction": "incoming",
    "type": "photo",
    "mediaUrl": "/assets/images/chats/esta_matcha.jpg",
    "text": "Nih titipan dari adeknya Panji udah nyampe. Enak juga rasanya.",
    "date": "2026-10-18",
    "time": "16:00"
  },
  {
    "id": "esta-047",
    "direction": "outgoing",
    "text": "Tuh kan dibilangin juga apa. Titip salam ya buat dia wkwk.",
    "date": "2026-10-18",
    "time": "16:10"
  },
  {
    "id": "esta-048",
    "direction": "incoming",
    "text": "Adek Panji tadi udah pulang. Kayaknya lega banget setelah ngobrol sama Papa",
    "date": "2026-10-18",
    "time": "17:10"
  },
  {
    "id": "esta-049",
    "direction": "outgoing",
    "text": "Tuh kan, Papa kalau udah bahas motor lupa mau interogasi orang",
    "date": "2026-10-18",
    "time": "17:13"
  },
  {
    "id": "esta-050",
    "direction": "incoming",
    "text": "Bener. Papi juga malah nawarin makanan buat dibawa pulang",
    "date": "2026-10-18",
    "time": "17:15"
  },
  {
    "id": "esta-051",
    "direction": "outgoing",
    "text": "Panji pasti seneng, itu bocah doyan banget kalau dikasih bekal",
    "date": "2026-10-18",
    "time": "17:17"
  },
  {
    "id": "esta-052",
    "direction": "incoming",
    "text": "Lu sendiri udah makan belum? Jangan-jangan malah sibuk ngobrol",
    "date": "2026-10-18",
    "time": "17:19"
  },
  {
    "id": "esta-053",
    "direction": "outgoing",
    "text": "Udah bang, aman",
    "date": "2026-10-18",
    "time": "17:21"
  },
  {
    "id": "esta-054",
    "direction": "incoming",
    "text": "Lu butuh apa-apa buat di apart? Gue bisa anter kalau besok pulang kerja",
    "date": "2026-10-20",
    "time": "20:30"
  },
  {
    "id": "esta-055",
    "direction": "outgoing",
    "text": "Aman. Panji udah bawain makanan, gue cuma disuruh istirahat",
    "date": "2026-10-20",
    "time": "20:33"
  },
  {
    "id": "esta-056",
    "direction": "incoming",
    "text": "Bagus. Sekali-kali nurut sama orang",
    "date": "2026-10-20",
    "time": "20:35"
  },
  {
    "id": "esta-057",
    "direction": "outgoing",
    "text": "Jangan kompak sama dia dong bang",
    "date": "2026-10-20",
    "time": "20:37"
  },
  {
    "id": "esta-058",
    "direction": "incoming",
    "text": "Gue ga sengaja liat Pian mondar-mandir depan karpet tadi. Mencurigakan",
    "date": "2026-10-27",
    "time": "14:10"
  },
  {
    "id": "esta-059",
    "direction": "outgoing",
    "text": "Dia lagi nyari cara supaya ga ketahuan Papi kali bang",
    "date": "2026-10-27",
    "time": "14:12"
  },
  {
    "id": "esta-060",
    "direction": "incoming",
    "text": "Gue ga mau ikut campur. Nanti kebagian nyuci karpet",
    "date": "2026-10-27",
    "time": "14:14"
  },
  {
    "id": "esta-061",
    "direction": "outgoing",
    "text": "Pilihan yang bijak",
    "date": "2026-10-27",
    "time": "14:16"
  },
  {
    "id": "esta-062",
    "direction": "outgoing",
    "text": "Bang, kemeja item gue di kamar lo ga?",
    "date": "2026-10-28",
    "time": "07:10"
  },
  {
    "id": "esta-063",
    "direction": "incoming",
    "text": "Engga dek, emang kenapa?",
    "date": "2026-10-28",
    "time": "07:15"
  },
  {
    "id": "esta-064",
    "direction": "outgoing",
    "text": "Ilang njir, padahal mau dipake pagi ini ke site visit.",
    "date": "2026-10-28",
    "time": "07:16"
  },
  {
    "id": "esta-065",
    "direction": "incoming",
    "text": "Coba lu cari di keranjang setrikaan deh, kemaren Bi Inah yg rapiin kyknya.",
    "date": "2026-10-28",
    "time": "07:20"
  },
  {
    "id": "esta-066",
    "direction": "outgoing",
    "text": "Oh iya ada bang, ketumpuk jas Papa. Tq ya.",
    "date": "2026-10-28",
    "time": "07:25"
  },
  {
    "id": "esta-067",
    "direction": "incoming",
    "text": "Makanya taro barang jangan sembarangan.",
    "date": "2026-10-28",
    "time": "07:30"
  },
  {
    "id": "esta-068",
    "direction": "incoming",
    "text": "Jangan lupa malam ini pulang. Papa udah nanya dari tadi",
    "date": "2026-10-29",
    "time": "17:30"
  },
  {
    "id": "esta-069",
    "direction": "outgoing",
    "text": "Iya bang. Panji juga ikut, katanya mau sekalian ngobrol sama Papa",
    "date": "2026-10-29",
    "time": "17:33"
  },
  {
    "id": "esta-070",
    "direction": "incoming",
    "text": "Bagus. Gue kabarin Papi biar lauknya ditambah",
    "date": "2026-10-29",
    "time": "17:35"
  }
];
