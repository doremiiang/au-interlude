export const HELIO_MESSAGES = [
  {
    "id": "helio-001",
    "direction": "incoming",
    "type": "photo",
    "mediaUrl": "/assets/images/chats/helio_cat_keyboard.jpg",
    "text": "Gimana mau ngerjain kerjaan kantor kalo keyboard gue didudukin terus.",
    "date": "2026-09-16",
    "time": "14:10"
  },
  {
    "id": "helio-002",
    "direction": "outgoing",
    "text": "Itu tandanya lu disuruh istirahat, Yo. Kucing aja ngerti lu butuh rebahan.",
    "date": "2026-09-16",
    "time": "14:30"
  },
  {
    "id": "helio-003",
    "direction": "incoming",
    "text": "Dia tidur dari jam 12 siang. Rekor sih ini malesnya nurun ke siapa tau.",
    "date": "2026-09-16",
    "time": "14:32"
  },
  {
    "id": "helio-004",
    "direction": "incoming",
    "text": "Barusan gue angkat kucingnya dari keyboard, dia pindah tidur ke atas buku",
    "date": "2026-09-16",
    "time": "14:45"
  },
  {
    "id": "helio-005",
    "direction": "outgoing",
    "text": "Minimal sekarang yang dia dudukin bukan kerjaan lu",
    "date": "2026-09-16",
    "time": "14:48"
  },
  {
    "id": "helio-006",
    "direction": "incoming",
    "text": "Iya, tapi buku yang gue perluin. Dia tau banget milih tempat",
    "date": "2026-09-16",
    "time": "14:50"
  },
  {
    "id": "helio-007",
    "direction": "outgoing",
    "text": "Kucing lu punya agenda sendiri kayaknya",
    "date": "2026-09-16",
    "time": "14:52"
  },
  {
    "id": "helio-008",
    "direction": "incoming",
    "text": "Qil, ada rekomendasi tempat ngopi yg sepi ga daerah Bekasi? Mau nyari suasana tenang buat ngerjain revisi draf.",
    "date": "2026-09-22",
    "time": "10:15"
  },
  {
    "id": "helio-009",
    "direction": "outgoing",
    "text": "Coba ke Kopi Teras deh. Lumayan tenang, ga berisik musiknya, colokan juga banyak.",
    "date": "2026-09-22",
    "time": "10:40"
  },
  {
    "id": "helio-010",
    "direction": "incoming",
    "text": "Oh oke, nanti sore gue coba kesana. Thanks infonya.",
    "date": "2026-09-22",
    "time": "10:42"
  },
  {
    "id": "helio-011",
    "direction": "incoming",
    "text": "Kopi Teras enak juga. Musiknya pelan, gue bisa duduk dekat jendela tanpa keganggu",
    "date": "2026-09-22",
    "time": "17:30"
  },
  {
    "id": "helio-012",
    "direction": "outgoing",
    "text": "Nah kan. Gue sering ke situ kalau butuh fokus",
    "date": "2026-09-22",
    "time": "17:33"
  },
  {
    "id": "helio-013",
    "direction": "incoming",
    "text": "Cuma colokannya rebutan. Tadi ada yang pindah meja pas gue mau charge",
    "date": "2026-09-22",
    "time": "17:35"
  },
  {
    "id": "helio-014",
    "direction": "outgoing",
    "text": "Dateng lebih awal aja besok. Jam segitu biasanya belum penuh",
    "date": "2026-09-22",
    "time": "17:37"
  },
  {
    "id": "helio-015",
    "direction": "incoming",
    "text": "Tadi pas bongkar file lama, nemu foto tugas maket kita taun kedua kuliah.",
    "date": "2026-09-30",
    "time": "21:00"
  },
  {
    "id": "helio-016",
    "direction": "outgoing",
    "text": "Anjir jangan diingetin, bikin pusing pale. Hampir ga tidur seminggu demi itu doang.",
    "date": "2026-09-30",
    "time": "21:15"
  },
  {
    "id": "helio-017",
    "direction": "incoming",
    "text": "Tapi emang paling sabar sih lu dlu ngerjain detailnya. Gue udah mau banting cutter wkwk.",
    "date": "2026-09-30",
    "time": "21:18"
  },
  {
    "id": "helio-018",
    "direction": "outgoing",
    "text": "Gue ngomel-ngomel mulu padahal dalem hati nangis darah.",
    "date": "2026-09-30",
    "time": "21:20"
  },
  {
    "id": "helio-019",
    "direction": "incoming",
    "text": "Gue nemu folder foto tugas kuliah kita yang lain. Ada yang rambut lu masih gondrong",
    "date": "2026-09-30",
    "time": "21:30"
  },
  {
    "id": "helio-020",
    "direction": "outgoing",
    "text": "Jangan kirim ke siapa-siapa. Gue udah berdamai sama masa lalu itu",
    "date": "2026-09-30",
    "time": "21:33"
  },
  {
    "id": "helio-021",
    "direction": "incoming",
    "text": "Tenang. Cuma gue simpen buat lucu-lucuan sendiri",
    "date": "2026-09-30",
    "time": "21:35"
  },
  {
    "id": "helio-022",
    "direction": "outgoing",
    "text": "Bagus. Jangan sampai Anta lihat, dia bisa bikin bahan sebulan",
    "date": "2026-09-30",
    "time": "21:37"
  },
  {
    "id": "helio-023",
    "direction": "incoming",
    "type": "voice",
    "duration": "0:06",
    "transcript": "Qil, kucing baru gue aktif banget loncat ke atas lemari. Jantung gue mau copot.",
    "date": "2026-10-08",
    "time": "16:30"
  },
  {
    "id": "helio-024",
    "direction": "outgoing",
    "text": "Hahaha selamat berjuang jadi budak anabul ya.",
    "date": "2026-10-08",
    "time": "16:45"
  },
  {
    "id": "helio-025",
    "direction": "incoming",
    "text": "Gue pasang alas di atas lemari. Dia malah sekarang suka duduk di sana",
    "date": "2026-10-08",
    "time": "16:50"
  },
  {
    "id": "helio-026",
    "direction": "outgoing",
    "text": "Lebih aman daripada loncat pas lu lagi pegang gelas",
    "date": "2026-10-08",
    "time": "16:53"
  },
  {
    "id": "helio-027",
    "direction": "incoming",
    "text": "Betul. Tadi hampir kena keyboard lagi",
    "date": "2026-10-08",
    "time": "16:55"
  },
  {
    "id": "helio-028",
    "direction": "outgoing",
    "text": "Taruh mainan di dekat meja biar dia punya tempat sendiri",
    "date": "2026-10-08",
    "time": "16:57"
  },
  {
    "id": "helio-029",
    "direction": "incoming",
    "text": "Qil, gue lagi rapihin layout meja kerja. Menurut lu monitor lebih enak lurus atau agak miring ke jendela?",
    "date": "2026-10-14",
    "time": "20:00"
  },
  {
    "id": "helio-030",
    "direction": "outgoing",
    "text": "Lurus aja kalau cahaya jendelanya dari samping. Biar ga mantul ke layar",
    "date": "2026-10-14",
    "time": "20:03"
  },
  {
    "id": "helio-031",
    "direction": "incoming",
    "text": "Oke. Gue coba besok pagi pas cahayanya masuk",
    "date": "2026-10-14",
    "time": "20:05"
  },
  {
    "id": "helio-032",
    "direction": "outgoing",
    "text": "Foto hasilnya nanti, gue cek",
    "date": "2026-10-14",
    "time": "20:07"
  },
  {
    "id": "helio-033",
    "direction": "incoming",
    "text": "Qil, lu gapapa?",
    "date": "2026-10-20",
    "time": "19:40"
  },
  {
    "id": "helio-034",
    "direction": "incoming",
    "text": "Liat SG Panji lu diinfus. Semoga lekas membaik ya kondisi badan lu.",
    "date": "2026-10-20",
    "time": "19:41"
  },
  {
    "id": "helio-035",
    "direction": "outgoing",
    "text": "Ah si Panji lebay banget emang. Iya Yo, cuma kecapekan dikit doang kok, bukan sakit parah. Thanks ya.",
    "date": "2026-10-20",
    "time": "19:50"
  },
  {
    "id": "helio-036",
    "direction": "incoming",
    "text": "Baguslah kalo gitu. Jangan keseringan di-forsir lemburnya.",
    "date": "2026-10-20",
    "time": "19:52"
  },
  {
    "id": "helio-037",
    "direction": "incoming",
    "text": "Gue sempet khawatir pas liat story itu. Seneng dengernya lu udah mendingan",
    "date": "2026-10-20",
    "time": "20:10"
  },
  {
    "id": "helio-038",
    "direction": "outgoing",
    "text": "Makasih, Yo. Gue juga ga nyangka jadi serame itu cuma gara-gara story",
    "date": "2026-10-20",
    "time": "20:13"
  },
  {
    "id": "helio-039",
    "direction": "incoming",
    "text": "Mungkin karena orang-orang peduli. Tapi semoga lain kali lu ga perlu sampai diinfus buat istirahat",
    "date": "2026-10-20",
    "time": "20:15"
  },
  {
    "id": "helio-040",
    "direction": "outgoing",
    "text": "Noted. Gue usahain ga ngulang",
    "date": "2026-10-20",
    "time": "20:17"
  },
  {
    "id": "helio-041",
    "direction": "incoming",
    "type": "photo",
    "mediaUrl": "/assets/images/chats/helio_workspace.jpg",
    "text": "Gue baru ganti posisi meja kerja biar dapet cahaya pagi. Menurut lu pencahayaannya udah pas belum?",
    "date": "2026-10-27",
    "time": "11:00"
  },
  {
    "id": "helio-042",
    "direction": "outgoing",
    "text": "Udah oke itu, pas di samping jendela. Asal jangan pas siang bolong kena sorot matahari langsung aja, nanti silau ke layar monitor.",
    "date": "2026-10-27",
    "time": "11:20"
  },
  {
    "id": "helio-043",
    "direction": "incoming",
    "text": "Oh iya bener juga. Nanti gue geser dikit tirainya. Thanks sarannya, arsitek.",
    "date": "2026-10-27",
    "time": "11:25"
  },
  {
    "id": "helio-044",
    "direction": "incoming",
    "text": "Tirai yang lu saranin kemarin berhasil. Siang tadi layarnya ga silau",
    "date": "2026-10-27",
    "time": "11:30"
  },
  {
    "id": "helio-045",
    "direction": "outgoing",
    "text": "Tuh kan. Kadang solusinya ga perlu beli meja baru",
    "date": "2026-10-27",
    "time": "11:33"
  },
  {
    "id": "helio-046",
    "direction": "incoming",
    "text": "Gue hampir beli lampu meja juga",
    "date": "2026-10-27",
    "time": "11:35"
  },
  {
    "id": "helio-047",
    "direction": "outgoing",
    "text": "Tahan dulu. Lihat kebutuhan benerannya",
    "date": "2026-10-27",
    "time": "11:37"
  },
  {
    "id": "helio-048",
    "direction": "incoming",
    "text": "Kabel charger gue jadi korban lagi. Kucingnya gigit ujung kabel, untung belum rusak",
    "date": "2026-10-30",
    "time": "19:00"
  },
  {
    "id": "helio-049",
    "direction": "outgoing",
    "text": "Beli pelindung kabel yang spiral itu. Daripada tiap minggu ganti",
    "date": "2026-10-30",
    "time": "19:03"
  },
  {
    "id": "helio-050",
    "direction": "incoming",
    "text": "Iya, besok gue cari. Makasih ya",
    "date": "2026-10-30",
    "time": "19:05"
  }
];
