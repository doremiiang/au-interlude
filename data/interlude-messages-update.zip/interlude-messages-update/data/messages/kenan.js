export const KENAN_MESSAGES = [
  {
    "id": "kenan-001",
    "direction": "incoming",
    "text": "Bang, ada duit nganggur ga?",
    "date": "2026-09-20",
    "time": "10:00"
  },
  {
    "id": "kenan-002",
    "direction": "incoming",
    "text": "Kalo ada pinjem dong sejuta. Buat nambahin beli velg motor.",
    "date": "2026-09-20",
    "time": "10:01"
  },
  {
    "id": "kenan-003",
    "direction": "outgoing",
    "text": "Duit mulu pikiran lu.",
    "date": "2026-09-20",
    "time": "11:30"
  },
  {
    "id": "kenan-004",
    "direction": "outgoing",
    "text": "Gue tf 500 aja. Jangan lupa ganti ntar pas lu dapet uang jajan dari Papa.",
    "date": "2026-09-20",
    "time": "11:32"
  },
  {
    "id": "kenan-005",
    "direction": "incoming",
    "text": "Sip mantap. Tumben lu baik bang ga ngomel dulu wkwk.",
    "date": "2026-09-20",
    "time": "11:45"
  },
  {
    "id": "kenan-006",
    "direction": "outgoing",
    "text": "Banyak bacot gue tarik lagi nih.",
    "date": "2026-09-20",
    "time": "12:00"
  },
  {
    "id": "kenan-007",
    "direction": "incoming",
    "text": "Bang, velg yang gue liat kemarin ternyata ada warna item doff juga",
    "date": "2026-09-20",
    "time": "12:10"
  },
  {
    "id": "kenan-008",
    "direction": "outgoing",
    "text": "Terus? Mau beli dua warna sekalian?",
    "date": "2026-09-20",
    "time": "12:12"
  },
  {
    "id": "kenan-009",
    "direction": "incoming",
    "text": "Nanya doang. Kalau bagus kan siapa tau",
    "date": "2026-09-20",
    "time": "12:14"
  },
  {
    "id": "kenan-010",
    "direction": "outgoing",
    "text": "Fokus bayar utang 500 dulu, baru mikirin warna",
    "date": "2026-09-20",
    "time": "12:16"
  },
  {
    "id": "kenan-011",
    "direction": "incoming",
    "text": "Iya iya bos, galak amat",
    "date": "2026-09-20",
    "time": "12:18"
  },
  {
    "id": "kenan-012",
    "direction": "outgoing",
    "text": "Dek, cekin meja ruang tengah dong. Buku sketsa gue ada di situ ga?",
    "date": "2026-09-26",
    "time": "14:00"
  },
  {
    "id": "kenan-013",
    "direction": "incoming",
    "text": "Bentar.",
    "date": "2026-09-26",
    "time": "14:15"
  },
  {
    "id": "kenan-014",
    "direction": "incoming",
    "type": "photo",
    "mediaUrl": "/assets/images/chats/kenan_sketchbook.jpg",
    "text": "Ini?",
    "date": "2026-09-26",
    "time": "14:16"
  },
  {
    "id": "kenan-015",
    "direction": "outgoing",
    "text": "Nah iya! Simpenin di kamar gue cepet sebelum dicoret-coret Theo.",
    "date": "2026-09-26",
    "time": "14:20"
  },
  {
    "id": "kenan-016",
    "direction": "incoming",
    "text": "Wani piro?",
    "date": "2026-09-26",
    "time": "14:21"
  },
  {
    "id": "kenan-017",
    "direction": "outgoing",
    "text": "Dih, cepetan atau ntar gue aduin ke Papi lu ketauan ngerokok di balkon kemaren malem.",
    "date": "2026-09-26",
    "time": "14:23"
  },
  {
    "id": "kenan-018",
    "direction": "incoming",
    "text": "Anjir maennya anceman. Yaudah aman udah di kasur lu.",
    "date": "2026-09-26",
    "time": "14:25"
  },
  {
    "id": "kenan-019",
    "direction": "incoming",
    "text": "Buku sketsa lu aman. Tapi Theo tadi sempet nanya boleh liat isi gambarnya ga",
    "date": "2026-09-26",
    "time": "14:30"
  },
  {
    "id": "kenan-020",
    "direction": "outgoing",
    "text": "Jangan kasih. Banyak gambar kerjaan yang belum boleh diliat orang",
    "date": "2026-09-26",
    "time": "14:32"
  },
  {
    "id": "kenan-021",
    "direction": "incoming",
    "text": "Santai, gue bilang itu buku mantra",
    "date": "2026-09-26",
    "time": "14:34"
  },
  {
    "id": "kenan-022",
    "direction": "outgoing",
    "text": "Bangsat, bikin dia penasaran aja",
    "date": "2026-09-26",
    "time": "14:36"
  },
  {
    "id": "kenan-023",
    "direction": "incoming",
    "text": "Pa udah bisa buka Facebook lagi belum? Gue mau tunjukin cara bikin story",
    "date": "2026-10-05",
    "time": "20:00"
  },
  {
    "id": "kenan-024",
    "direction": "outgoing",
    "text": "Jangan ajarin Papa macam-macam dulu. Satu fitur aja dia udah bikin grup keluarga heboh",
    "date": "2026-10-05",
    "time": "20:03"
  },
  {
    "id": "kenan-025",
    "direction": "incoming",
    "text": "Wkwkwk padahal seru kalau Papa bisa bikin story",
    "date": "2026-10-05",
    "time": "20:05"
  },
  {
    "id": "kenan-026",
    "direction": "outgoing",
    "text": "Lu yang nanti disuruh tanggung jawab",
    "date": "2026-10-05",
    "time": "20:07"
  },
  {
    "id": "kenan-027",
    "direction": "incoming",
    "text": "Bang lu kudu liat kelakuan adek lu si Theo babi emang.",
    "date": "2026-10-11",
    "time": "14:35"
  },
  {
    "id": "kenan-028",
    "direction": "incoming",
    "type": "sticker",
    "mediaUrl": "/assets/stickers/kenan_angry.png",
    "date": "2026-10-11",
    "time": "14:36"
  },
  {
    "id": "kenan-029",
    "direction": "outgoing",
    "text": "Kenapa lagi sih? Itu tadi di grup heboh.",
    "date": "2026-10-11",
    "time": "14:40"
  },
  {
    "id": "kenan-030",
    "direction": "incoming",
    "text": "Muka gue dicoret spidol permanen njir. Gue cuci pake sabun cuci piring kaga ilang.",
    "date": "2026-10-11",
    "time": "14:42"
  },
  {
    "id": "kenan-031",
    "direction": "outgoing",
    "text": "Wkwkwkwk mampus. Makanya kebo banget lu tidur dibangunin kaga bangun.",
    "date": "2026-10-11",
    "time": "14:45"
  },
  {
    "id": "kenan-032",
    "direction": "incoming",
    "text": "Lu beliin gue skincare yg kenceng dong bang besok, perih nih muka gue gosok mulu.",
    "date": "2026-10-11",
    "time": "14:48"
  },
  {
    "id": "kenan-033",
    "direction": "outgoing",
    "text": "Suruh Papi bawa lu ke klinik kecantikan aja sana.",
    "date": "2026-10-11",
    "time": "14:50"
  },
  {
    "id": "kenan-034",
    "direction": "incoming",
    "text": "Sabun muka gue belum bisa ilangin spidolnya. Papi bilang besok aja dibawa ke klinik",
    "date": "2026-10-11",
    "time": "15:00"
  },
  {
    "id": "kenan-035",
    "direction": "outgoing",
    "text": "Nah, dengerin Papi. Jangan digosok terus, merah muka lu",
    "date": "2026-10-11",
    "time": "15:02"
  },
  {
    "id": "kenan-036",
    "direction": "incoming",
    "text": "Gue udah diem, yang lain malah ngeledekin",
    "date": "2026-10-11",
    "time": "15:04"
  },
  {
    "id": "kenan-037",
    "direction": "outgoing",
    "text": "Karena lucu",
    "date": "2026-10-11",
    "time": "15:06"
  },
  {
    "id": "kenan-038",
    "direction": "incoming",
    "text": "Bang. Temen gue bilang ngeliat mobil lu di puncak.",
    "date": "2026-10-12",
    "time": "20:00"
  },
  {
    "id": "kenan-039",
    "direction": "incoming",
    "text": "Lu lagi liburan apa gimana dah ga bilang bilang ke rumah.",
    "date": "2026-10-12",
    "time": "20:01"
  },
  {
    "id": "kenan-040",
    "direction": "outgoing",
    "text": "Iya nemenin Panji nyari sparepart sekalian mampir.",
    "date": "2026-10-12",
    "time": "21:10"
  },
  {
    "id": "kenan-041",
    "direction": "incoming",
    "type": "voice",
    "duration": "0:05",
    "transcript": "Bawain mochi lho ya baliknya. Awas aja lu lupa. Kalo lupa gue kunciin ntar pintu rumah.",
    "date": "2026-10-12",
    "time": "21:15"
  },
  {
    "id": "kenan-042",
    "direction": "outgoing",
    "text": "Y.",
    "date": "2026-10-12",
    "time": "21:20"
  },
  {
    "id": "kenan-043",
    "direction": "incoming",
    "text": "Mochi dari Puncak mana? Yang deket rest area atau yang di toko kecil?",
    "date": "2026-10-12",
    "time": "21:30"
  },
  {
    "id": "kenan-044",
    "direction": "outgoing",
    "text": "Yang bungkus putih. Jangan dimakan semua sendiri",
    "date": "2026-10-12",
    "time": "21:32"
  },
  {
    "id": "kenan-045",
    "direction": "incoming",
    "text": "Gue cuma nanya, nanti gue bagi sama Theo",
    "date": "2026-10-12",
    "time": "21:34"
  },
  {
    "id": "kenan-046",
    "direction": "incoming",
    "type": "call",
    "status": "missed",
    "date": "2026-10-20",
    "time": "19:15"
  },
  {
    "id": "kenan-047",
    "direction": "incoming",
    "text": "Woi bang. Lu sakit beneran apa akal-akalan si Panji doang cari perhatian?",
    "date": "2026-10-20",
    "time": "19:16"
  },
  {
    "id": "kenan-048",
    "direction": "incoming",
    "text": "Lemah banget lu, makanya jangan kerja rodi mulu.",
    "date": "2026-10-20",
    "time": "19:17"
  },
  {
    "id": "kenan-049",
    "direction": "outgoing",
    "text": "Bacot lu bocil. Cuma infus vitamin doang.",
    "date": "2026-10-20",
    "time": "19:20"
  },
  {
    "id": "kenan-050",
    "direction": "incoming",
    "text": "Yaudah ntar gue jenguk ke apart deh kalo dapet tebengan Bang Esta. Mau dibawain apaan?",
    "date": "2026-10-20",
    "time": "19:22"
  },
  {
    "id": "kenan-051",
    "direction": "outgoing",
    "text": "Gausah, lu malah ngabisin makanan gue ntar kalo ke sini.",
    "date": "2026-10-20",
    "time": "19:25"
  },
  {
    "id": "kenan-052",
    "direction": "incoming",
    "text": "Dih ditawarin juga. Yaudah gue doain cepet sembuh dah biar bisa dipalak lagi.",
    "date": "2026-10-20",
    "time": "19:27"
  },
  {
    "id": "kenan-053",
    "direction": "incoming",
    "text": "Beneran udah ga pusing? Gue tadi liat story Panji, tangan lu ditusuk jarum",
    "date": "2026-10-20",
    "time": "20:00"
  },
  {
    "id": "kenan-054",
    "direction": "outgoing",
    "text": "Udah. Lu jangan ikut-ikutan Papa panik",
    "date": "2026-10-20",
    "time": "20:02"
  },
  {
    "id": "kenan-055",
    "direction": "incoming",
    "text": "Gue ga panik. Cuma kalau lu sakit, siapa yang mau gue palak",
    "date": "2026-10-20",
    "time": "20:04"
  },
  {
    "id": "kenan-056",
    "direction": "outgoing",
    "text": "Alasan lu selalu duit",
    "date": "2026-10-20",
    "time": "20:06"
  },
  {
    "id": "kenan-057",
    "direction": "incoming",
    "text": "Bang transfer dong.",
    "date": "2026-10-29",
    "time": "17:00"
  },
  {
    "id": "kenan-058",
    "direction": "incoming",
    "text": "Lagi bokek nih, mau nonton sama temen.",
    "date": "2026-10-29",
    "time": "17:01"
  },
  {
    "id": "kenan-059",
    "direction": "outgoing",
    "text": "Ga. Lu masih utang 300 rebu ke gue kemarin.",
    "date": "2026-10-29",
    "time": "17:40"
  },
  {
    "id": "kenan-060",
    "direction": "incoming",
    "text": "Elah ntar diganti, pelit amat lu sama adek sendiri.",
    "date": "2026-10-29",
    "time": "17:45"
  },
  {
    "id": "kenan-061",
    "direction": "outgoing",
    "text": "Minta Papa sana, lu kan anak kesayangan Papa.",
    "date": "2026-10-29",
    "time": "17:50"
  },
  {
    "id": "kenan-062",
    "direction": "incoming",
    "text": "Papa lagi mode pelit juga diomelin Papi wkwk, ayo lah bang gocap jg gpp.",
    "date": "2026-10-29",
    "time": "17:52"
  },
  {
    "id": "kenan-063",
    "direction": "outgoing",
    "text": "Y.",
    "date": "2026-10-29",
    "time": "17:55"
  },
  {
    "id": "kenan-064",
    "direction": "incoming",
    "text": "Gue dapet uang jajan tambahan dari Papa. Mau gue bayar utang 300 dulu apa minggu depan?",
    "date": "2026-10-29",
    "time": "18:10"
  },
  {
    "id": "kenan-065",
    "direction": "outgoing",
    "text": "Transfer aja sekarang. Jangan cuma janji",
    "date": "2026-10-29",
    "time": "18:12"
  },
  {
    "id": "kenan-066",
    "direction": "incoming",
    "text": "Oke. Tapi traktir gue minum ya kalau ketemu",
    "date": "2026-10-29",
    "time": "18:14"
  },
  {
    "id": "kenan-067",
    "direction": "outgoing",
    "text": "Nanti liat kelakuan lu",
    "date": "2026-10-29",
    "time": "18:16"
  }
];
