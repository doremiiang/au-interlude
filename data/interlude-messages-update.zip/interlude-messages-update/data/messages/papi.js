export const PAPI_MESSAGES = [
  {
    "id": "bian-001",
    "direction": "incoming",
    "type": "photo",
    "mediaUrl": "/assets/images/chats/bian_perfume.jpg",
    "text": "Sayang, liat deh Papi akhirnya beli parfum Jo Malone yang kamu pengen waktu itu.",
    "date": "2026-09-16",
    "time": "14:20"
  },
  {
    "id": "bian-002",
    "direction": "outgoing",
    "text": "Ihhhh mauuu. Bagi dikit Pi ke botol kecil donggg.",
    "date": "2026-09-16",
    "time": "14:45"
  },
  {
    "id": "bian-003",
    "direction": "incoming",
    "text": "Beli sendiri dong arsitek muda 😝 Bercanda ih, ntar Papi sisihin buat kamu pas pulang ke rumah ya.",
    "date": "2026-09-16",
    "time": "14:50"
  },
  {
    "id": "bian-004",
    "direction": "outgoing",
    "text": "Hehehe makasih Papi cantik.",
    "date": "2026-09-16",
    "time": "14:55"
  },
  {
    "id": "bian-005",
    "direction": "incoming",
    "text": "Papi sisihin parfum kamu sedikit di botol kecil. Nanti kalau pulang jangan lupa ambil ya",
    "date": "2026-09-16",
    "time": "15:00"
  },
  {
    "id": "bian-006",
    "direction": "outgoing",
    "text": "Papi paling baik. Shaqil jadi punya parfum kembaran",
    "date": "2026-09-16",
    "time": "15:03"
  },
  {
    "id": "bian-007",
    "direction": "incoming",
    "text": "Jangan dipakai banyak-banyak, nanti cepat habis. Satu semprot cukup 😘",
    "date": "2026-09-16",
    "time": "15:05"
  },
  {
    "id": "bian-008",
    "direction": "incoming",
    "text": "Sayangg.",
    "date": "2026-09-22",
    "time": "11:00"
  },
  {
    "id": "bian-009",
    "direction": "incoming",
    "text": "Papi lagi liat-liat kemeja nih di mall. Kamu mau dibeliin nggak warna navy?",
    "date": "2026-09-22",
    "time": "11:01"
  },
  {
    "id": "bian-010",
    "direction": "outgoing",
    "text": "Boleh Pi. Ukuran L ya.",
    "date": "2026-09-22",
    "time": "12:15"
  },
  {
    "id": "bian-011",
    "direction": "incoming",
    "text": "Siap boss. Btw malam ini tidur rumah kan?",
    "date": "2026-09-22",
    "time": "12:20"
  },
  {
    "id": "bian-012",
    "direction": "outgoing",
    "text": "Iya nanti Shaqil balik ke sana. Suruh Papa beliin martabak dong Pi.",
    "date": "2026-09-22",
    "time": "12:40"
  },
  {
    "id": "bian-013",
    "direction": "incoming",
    "text": "Udah Papi omongin tadi. Eh si Panji suruh mampir juga aja makan malem di sini.",
    "date": "2026-09-22",
    "time": "12:45"
  },
  {
    "id": "bian-014",
    "direction": "incoming",
    "text": "Kemeja navy-nya sudah Papi beli. Ukurannya L, kalau kebesaran nanti bisa ditukar",
    "date": "2026-09-22",
    "time": "12:50"
  },
  {
    "id": "bian-015",
    "direction": "outgoing",
    "text": "Makasih Pi. Papi jangan lupa simpan struknya ya",
    "date": "2026-09-22",
    "time": "12:53"
  },
  {
    "id": "bian-016",
    "direction": "incoming",
    "text": "Sudah. Papi kan teliti kalau urusan belanja",
    "date": "2026-09-22",
    "time": "12:55"
  },
  {
    "id": "bian-017",
    "direction": "outgoing",
    "text": "Gatau deh dia lagi sibuk di bengkel, ntar ditanyain.",
    "date": "2026-09-22",
    "time": "13:00"
  },
  {
    "id": "bian-018",
    "direction": "incoming",
    "text": "Adek, tolong ajarin Papa kamu cara hapus video di pesbuk. Malu-maluin banget nge-share video bapak-bapak mancing mulu.",
    "date": "2026-10-05",
    "time": "19:10"
  },
  {
    "id": "bian-019",
    "direction": "outgoing",
    "text": "Wkwkwk biarin aja sih Pi, namanya juga bapak-bapak.",
    "date": "2026-10-05",
    "time": "19:30"
  },
  {
    "id": "bian-020",
    "direction": "incoming",
    "text": "Masalahnya dia nge-tag Papi juga! Temen-temen arisan Papi pada ngeliat, haduh bikin pusing emang bapakmu itu.",
    "date": "2026-10-05",
    "time": "19:35"
  },
  {
    "id": "bian-021",
    "direction": "outgoing",
    "text": "Iya iyaaa ntar besok Shaqil hapusin pas mampir ke rumah wkwk.",
    "date": "2026-10-05",
    "time": "19:40"
  },
  {
    "id": "bian-022",
    "direction": "incoming",
    "text": "Papa sudah janji tidak share video mancing lagi. Tapi Papi tetap pantau Facebook-nya",
    "date": "2026-10-05",
    "time": "19:50"
  },
  {
    "id": "bian-023",
    "direction": "outgoing",
    "text": "Wkwk Papi jadi admin akun Papa sekalian",
    "date": "2026-10-05",
    "time": "19:53"
  },
  {
    "id": "bian-024",
    "direction": "incoming",
    "text": "Daripada nanti Papi ikut viral karena tag-nya 😭",
    "date": "2026-10-05",
    "time": "19:55"
  },
  {
    "id": "bian-025",
    "direction": "incoming",
    "type": "photo",
    "mediaUrl": "/assets/images/chats/bian_outfit.jpg",
    "text": "Sayang, mending kemeja maroon atau yang biru dongker buat Papi kondangan temen arisan besok?",
    "date": "2026-10-13",
    "time": "15:00"
  },
  {
    "id": "bian-026",
    "direction": "outgoing",
    "text": "Yang maroon Pi, lebih cocok masuk ke warna kulit Papi.",
    "date": "2026-10-13",
    "time": "15:15"
  },
  {
    "id": "bian-027",
    "direction": "incoming",
    "text": "Tuh kan, insting Papi juga ke yang maroon. Papa kamu tadi nyuruh pilih yang mustard, norak banget seleranya.",
    "date": "2026-10-13",
    "time": "15:17"
  },
  {
    "id": "bian-028",
    "direction": "outgoing",
    "text": "Wkwkwk jangan dengerin Papa kalo soal baju, sesat.",
    "date": "2026-10-13",
    "time": "15:25"
  },
  {
    "id": "bian-029",
    "direction": "incoming",
    "text": "Besok Papi jadi pakai maroon. Tolong bilang Papa jangan ikut pilih aksesoris, ya",
    "date": "2026-10-13",
    "time": "15:30"
  },
  {
    "id": "bian-030",
    "direction": "outgoing",
    "text": "Siap. Kalau Papa mulai kasih saran, Shaqil alihkan perhatian",
    "date": "2026-10-13",
    "time": "15:33"
  },
  {
    "id": "bian-031",
    "direction": "incoming",
    "text": "Hahaha. Kamu memang anak andalan Papi",
    "date": "2026-10-13",
    "time": "15:35"
  },
  {
    "id": "bian-032",
    "direction": "incoming",
    "text": "Adek, itu kenapa story Panji foto tangan lu diinfus??",
    "date": "2026-10-20",
    "time": "19:00"
  },
  {
    "id": "bian-033",
    "direction": "incoming",
    "text": "Sakit ga bilang-bilang Papi ih. Papi mau ke apart sekarang ya.",
    "date": "2026-10-20",
    "time": "19:01"
  },
  {
    "id": "bian-034",
    "direction": "outgoing",
    "text": "Astaga lebay banget si Panji pake difoto sgala.",
    "date": "2026-10-20",
    "time": "19:15"
  },
  {
    "id": "bian-035",
    "direction": "outgoing",
    "text": "Cuma infus vitamin doang Pi kemaren, ga sakit. Udah seger ini Shaqil.",
    "date": "2026-10-20",
    "time": "19:16"
  },
  {
    "id": "bian-036",
    "direction": "incoming",
    "text": "Beneran? Kalau bohong Papi jewer nanti pas ketemu.",
    "date": "2026-10-20",
    "time": "19:25"
  },
  {
    "id": "bian-037",
    "direction": "incoming",
    "type": "voice",
    "duration": "0:14",
    "transcript": "Kamu tuh ya kalau dibilangin istirahat ngeyel. Papa kamu udah panik banget itu ngambil kunci mobil. Papi suruh Panji nginep jagain kamu malam ini ya.",
    "date": "2026-10-20",
    "time": "19:28"
  },
  {
    "id": "bian-038",
    "direction": "outgoing",
    "text": "Iya Piii, Panji udah di sini kok bawain bubur. Bilangin Papa gausah ke sini, jalanan macet.",
    "date": "2026-10-20",
    "time": "19:35"
  },
  {
    "id": "bian-039",
    "direction": "incoming",
    "text": "Yaudah, minum obatnya terus istirahat.",
    "date": "2026-10-20",
    "time": "19:40"
  },
  {
    "id": "bian-040",
    "direction": "incoming",
    "text": "Papi sudah tenang setelah dengar kamu bukan rawat inap. Tapi tetap jangan dipaksain kerja",
    "date": "2026-10-20",
    "time": "19:45"
  },
  {
    "id": "bian-041",
    "direction": "outgoing",
    "text": "Iya Pi. Papi juga jangan langsung panik kalau lihat story Panji lagi",
    "date": "2026-10-20",
    "time": "19:48"
  },
  {
    "id": "bian-042",
    "direction": "incoming",
    "text": "Itu pacar kamu yang harus belajar jangan asal unggah foto orang sakit",
    "date": "2026-10-20",
    "time": "19:50"
  },
  {
    "id": "bian-043",
    "direction": "incoming",
    "text": "Sayanggg.",
    "date": "2026-10-28",
    "time": "11:00"
  },
  {
    "id": "bian-044",
    "direction": "incoming",
    "text": "Papi mau ke salon nih, kamu mau ikut ga?",
    "date": "2026-10-28",
    "time": "11:01"
  },
  {
    "id": "bian-045",
    "direction": "outgoing",
    "text": "Kapan Pi? Shaqil masih di luar nih lagi survei lapangan.",
    "date": "2026-10-28",
    "time": "12:10"
  },
  {
    "id": "bian-046",
    "direction": "incoming",
    "text": "Yaudah kalo gbsa gpp, Papi berangkat sendiri aja.",
    "date": "2026-10-28",
    "time": "12:15"
  },
  {
    "id": "bian-047",
    "direction": "incoming",
    "text": "Nanti malam temenin Papi maskeran aja ya di rumah 😘",
    "date": "2026-10-28",
    "time": "12:16"
  },
  {
    "id": "bian-048",
    "direction": "outgoing",
    "text": "Oke Pi siap, nanti Shaqil beliin skincare mampir Watsons.",
    "date": "2026-10-28",
    "time": "13:00"
  },
  {
    "id": "bian-049",
    "direction": "incoming",
    "text": "Papi jadi ke salon tadi. Hasil potong rambutnya bagus, nanti kamu nilai sendiri",
    "date": "2026-10-28",
    "time": "17:00"
  },
  {
    "id": "bian-050",
    "direction": "outgoing",
    "text": "Pasti bagus, Papi kalau keluar salon selalu kayak mau pemotretan",
    "date": "2026-10-28",
    "time": "17:03"
  },
  {
    "id": "bian-051",
    "direction": "incoming",
    "text": "Jangan menggoda. Nanti malam kamu temenin Papi maskeran, kan?",
    "date": "2026-10-28",
    "time": "17:05"
  },
  {
    "id": "bian-052",
    "direction": "outgoing",
    "text": "Iya Pi. Shaqil sekalian bawa skincare yang kemarin dibeli",
    "date": "2026-10-28",
    "time": "17:07"
  },
  {
    "id": "bian-053",
    "direction": "incoming",
    "text": "Bagus. Papi mau lihat dulu sebelum kamu pakai, jangan asal campur produk",
    "date": "2026-10-28",
    "time": "17:09"
  },
  {
    "id": "bian-054",
    "direction": "incoming",
    "text": "Papi sudah siapkan baju rumah buat kamu. Kalau pulang malam ini, langsung ganti aja",
    "date": "2026-10-29",
    "time": "18:30"
  },
  {
    "id": "bian-055",
    "direction": "outgoing",
    "text": "Siap Pi. Panji juga ikut makan, ya",
    "date": "2026-10-29",
    "time": "18:33"
  },
  {
    "id": "bian-056",
    "direction": "incoming",
    "text": "Tentu. Papi sudah tambah lauk. Jangan pulang terlalu malam",
    "date": "2026-10-29",
    "time": "18:35"
  }
];
