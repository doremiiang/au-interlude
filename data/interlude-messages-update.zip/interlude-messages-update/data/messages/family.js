export const FAMILY_MESSAGES = [
  {
    "id": "family-001",
    "direction": "incoming",
    "sender": "theo",
    "text": "Papi, kak shaqil pelit ga mau beliin theo eskrim :(",
    "date": "2026-09-14",
    "time": "15:10"
  },
  {
    "id": "family-002",
    "direction": "incoming",
    "sender": "bian",
    "text": "Adek Shaqil, adiknya jangan dipajakin terus dong sayangg, kasian tuh nangis.",
    "date": "2026-09-14",
    "time": "15:15"
  },
  {
    "id": "family-003",
    "direction": "incoming",
    "sender": "kenan",
    "text": "Yaelah bang beli eskrim doang pelit amat lu, mentang-mentang tanggal tua wkwk.",
    "date": "2026-09-14",
    "time": "15:17"
  },
  {
    "id": "family-004",
    "direction": "outgoing",
    "text": "Bacot lu Kenan. Udah gue beliin tuh si Theo ntar malem dibawain.",
    "date": "2026-09-14",
    "time": "15:27"
  },
  {
    "id": "family-005",
    "direction": "incoming",
    "sender": "theo",
    "text": "Theo sudah makan es krimnya. Makasih ya Kak Shaqil ❤️",
    "date": "2026-09-14",
    "time": "19:00"
  },
  {
    "id": "family-006",
    "direction": "incoming",
    "sender": "pian",
    "text": "Sialan ban mobil gue kempes. Dek, gue bawa mobil lu ya @Shaqil, kunci ada di laci kan?",
    "date": "2026-09-15",
    "time": "07:35"
  },
  {
    "id": "family-007",
    "direction": "outgoing",
    "text": "Atas kulkas. Jangan lu tabrakin mobil gue awas aja.",
    "date": "2026-09-15",
    "time": "08:02"
  },
  {
    "id": "family-008",
    "direction": "incoming",
    "sender": "esta",
    "text": "Bang Pian kebiasaan, pantesan grasak grusuk di garasi dari tadi.",
    "date": "2026-09-15",
    "time": "08:10"
  },
  {
    "id": "family-009",
    "direction": "incoming",
    "sender": "bian",
    "text": "Besok jangan lupa balikin mobilnya sebelum jam makan siang, Pian",
    "date": "2026-09-15",
    "time": "08:12"
  },
  {
    "id": "family-010",
    "direction": "incoming",
    "sender": "pian",
    "text": "Iya Pi, ini lagi OTW kantor. Kunci cadangannya gue taro di tempat biasa",
    "date": "2026-09-15",
    "time": "08:14"
  },
  {
    "id": "family-011",
    "direction": "incoming",
    "sender": "esta",
    "text": "Jangan ngebut, Bang. Ban mobil lu aja belum beres",
    "date": "2026-09-15",
    "time": "08:16"
  },
  {
    "id": "family-012",
    "direction": "incoming",
    "sender": "feri",
    "text": "Pengumuman 📢 Hari ini Papa dan Papi mau masak besar! Anak-anak Papa pada pulang jam berapa hari ini??",
    "date": "2026-09-18",
    "time": "15:00"
  },
  {
    "id": "family-013",
    "direction": "incoming",
    "sender": "kenan",
    "text": "Kenan otw balik Pa! Laper bgt ini gila.",
    "date": "2026-09-18",
    "time": "15:05"
  },
  {
    "id": "family-014",
    "direction": "incoming",
    "sender": "esta",
    "text": "Gue udah di kamar dari tadi Pa.",
    "date": "2026-09-18",
    "time": "15:10"
  },
  {
    "id": "family-015",
    "direction": "outgoing",
    "text": "Shaqil di apartemen nugas Pa. Bang Pian nanti katanya mau anterin makanannya ke sini.",
    "date": "2026-09-18",
    "time": "16:25"
  },
  {
    "id": "family-016",
    "direction": "incoming",
    "sender": "bian",
    "text": "Makan malam hari ini enak. Shaqil, besok kalau sempat bawa rantangnya kembali ya",
    "date": "2026-09-18",
    "time": "20:00"
  },
  {
    "id": "family-017",
    "direction": "outgoing",
    "text": "Siap Pi. Rantangnya sudah dicuci, nanti Shaqil titip Bang Pian",
    "date": "2026-09-18",
    "time": "20:03"
  },
  {
    "id": "family-018",
    "direction": "incoming",
    "sender": "feri",
    "text": "Terima kasih. Anak Papa kalau urusan rantang bisa diandalkan 😁",
    "date": "2026-09-18",
    "time": "20:05"
  },
  {
    "id": "family-019",
    "direction": "incoming",
    "sender": "feri",
    "text": "Anak-anak... Ini kenapa hape papa fesbuknya bahasanya berubah inggris semua?? Tolong bantu kembalikan ya papa ga ngerti 😭😭😭",
    "date": "2026-09-22",
    "time": "19:05"
  },
  {
    "id": "family-020",
    "direction": "incoming",
    "sender": "kenan",
    "text": "WKWKWKWK bapak-bapak gaptek amat Pa ampun dah",
    "date": "2026-09-22",
    "time": "19:10"
  },
  {
    "id": "family-021",
    "direction": "incoming",
    "sender": "bian",
    "text": "Suruh siapa sih pencet-pencet hape sembarangan Feri. Bikin malu aja kamu tuh update status salah-salah.",
    "date": "2026-09-22",
    "time": "19:15"
  },
  {
    "id": "family-022",
    "direction": "outgoing",
    "text": "Udah tenang Pi. Ntar Shaqil mampir rumah Shaqil benerin tuh hapenya Papa.",
    "date": "2026-09-22",
    "time": "19:26"
  },
  {
    "id": "family-023",
    "direction": "incoming",
    "sender": "feri",
    "text": "Papa sudah bisa buka Facebook lagi. Jangan ada yang pencet pengaturan sembarangan ya",
    "date": "2026-09-22",
    "time": "19:30"
  },
  {
    "id": "family-024",
    "direction": "incoming",
    "sender": "kenan",
    "text": "Siap Pa. Nanti Kenan ajarin cara upload foto kalau Papa mau",
    "date": "2026-09-22",
    "time": "19:32"
  },
  {
    "id": "family-025",
    "direction": "incoming",
    "sender": "bian",
    "text": "Jangan dulu. Satu-satu, nanti Papa kebablasan",
    "date": "2026-09-22",
    "time": "19:34"
  },
  {
    "id": "family-026",
    "direction": "incoming",
    "sender": "theo",
    "text": "Kakak Shaqil buku gambar kakak kok ga ada di meja?",
    "date": "2026-09-26",
    "time": "14:15"
  },
  {
    "id": "family-027",
    "direction": "outgoing",
    "text": "JANGAN ADA YANG SENTUH! @kenan KENAN AMANIN BUKU GUE CEPET SEBELUM DICORET THEO!",
    "date": "2026-09-26",
    "time": "14:18"
  },
  {
    "id": "family-028",
    "direction": "incoming",
    "sender": "kenan",
    "text": "Udah gue amankan bos. Tenang aman di kamar lu. Theo lagi ngambek tuh di karpet wkwk.",
    "date": "2026-09-26",
    "time": "14:26"
  },
  {
    "id": "family-029",
    "direction": "incoming",
    "sender": "kenan",
    "text": "Buku sketsanya sudah aman. Theo jangan masuk kamar Kak Shaqil dulu ya",
    "date": "2026-09-26",
    "time": "14:30"
  },
  {
    "id": "family-030",
    "direction": "incoming",
    "sender": "theo",
    "text": "Theo cuma mau lihat gambarnya",
    "date": "2026-09-26",
    "time": "14:32"
  },
  {
    "id": "family-031",
    "direction": "incoming",
    "sender": "bian",
    "text": "Lihat boleh, pegang jangan. Itu barang kerja kakak",
    "date": "2026-09-26",
    "time": "14:34"
  },
  {
    "id": "family-032",
    "direction": "incoming",
    "sender": "bian",
    "text": "Sayangg... Hari ini Papi mau bikin rendang ayam kesukaan Panji. Nanti Panji diajak ke sini ya makan bareng keluarga.",
    "date": "2026-09-27",
    "time": "16:20"
  },
  {
    "id": "family-033",
    "direction": "outgoing",
    "text": "Gatau deh Pi Panji bisa apa engga, dia lagi di bengkel repot kayaknya.",
    "date": "2026-09-27",
    "time": "16:35"
  },
  {
    "id": "family-034",
    "direction": "incoming",
    "sender": "feri",
    "text": "Disuruh ke sini aja dek, Papa mau sekalian ngobrol masalah modif motor sama mantu.",
    "date": "2026-09-27",
    "time": "16:40"
  },
  {
    "id": "family-035",
    "direction": "incoming",
    "sender": "bian",
    "text": "Panji jadi datang malam ini. Papi sudah siapkan rendang tambahan",
    "date": "2026-09-27",
    "time": "17:00"
  },
  {
    "id": "family-036",
    "direction": "incoming",
    "sender": "panji",
    "text": "Siap Pi, saya berangkat setelah tutup bengkel",
    "date": "2026-09-27",
    "time": "17:03"
  },
  {
    "id": "family-037",
    "direction": "outgoing",
    "text": "Jangan telat, Pa udah mulai nanya dari tadi",
    "date": "2026-09-27",
    "time": "17:05"
  },
  {
    "id": "family-038",
    "direction": "incoming",
    "sender": "feri",
    "text": "Papa cuma mau ngobrol soal motor. Bukan interogasi 😁",
    "date": "2026-09-27",
    "time": "17:07"
  },
  {
    "id": "family-039",
    "direction": "incoming",
    "sender": "feri",
    "type": "photo",
    "mediaUrl": "/assets/images/chats/feri_goodmorning.jpg",
    "text": "Selamat Pagi Keluarga Tercinta... Awali hari dengan senyuman dan segelas kopi, semoga kita semua selalu dalam lindungan-Nya... ☕🌻🙏",
    "date": "2026-09-30",
    "time": "06:30"
  },
  {
    "id": "family-040",
    "direction": "incoming",
    "sender": "esta",
    "text": "Pagi Pa.",
    "date": "2026-09-30",
    "time": "06:45"
  },
  {
    "id": "family-041",
    "direction": "incoming",
    "sender": "kenan",
    "type": "sticker",
    "mediaUrl": "/assets/stickers/kenan_meme_salute.png",
    "date": "2026-09-30",
    "time": "06:50"
  },
  {
    "id": "family-042",
    "direction": "outgoing",
    "text": "Dapet wangsit dari mana pa grup jam segini udah dikirimin ginian wkwk.",
    "date": "2026-09-30",
    "time": "07:11"
  },
  {
    "id": "family-043",
    "direction": "incoming",
    "sender": "bian",
    "text": "FERI!!!! KENAPA KAMU NGE-TAG PAPI DI VIDEO BAPAK-BAPAK MANCING IKAN MAS?! TEMEN ARISAN PAPI PADA NGOMEN TAU GA! BIKIN MALU AJA!!! 😡😡",
    "date": "2026-10-05",
    "time": "19:15"
  },
  {
    "id": "family-044",
    "direction": "incoming",
    "sender": "kenan",
    "text": "WKWKWKWKWKWK MAMPUS PAPA DIMARAHIN PAPI",
    "date": "2026-10-05",
    "time": "19:17"
  },
  {
    "id": "family-045",
    "direction": "incoming",
    "sender": "feri",
    "text": "Ya ampun salah pencet itu sayang, maafin papa... 😰 Anak-anak ada yang tau cara hapusnya ga??",
    "date": "2026-10-05",
    "time": "19:20"
  },
  {
    "id": "family-046",
    "direction": "outgoing",
    "text": "Tinggal di-untag aja Pa astaga wkwkwk. Ntar besok Shaqil mampir ke rumah Shaqil yang hapusin deh, rusuh bener berdua.",
    "date": "2026-10-05",
    "time": "19:35"
  },
  {
    "id": "family-047",
    "direction": "incoming",
    "sender": "feri",
    "text": "Papa sudah hapus video mancingnya. Jangan ada yang bahas lagi ya 😅",
    "date": "2026-10-05",
    "time": "19:40"
  },
  {
    "id": "family-048",
    "direction": "incoming",
    "sender": "kenan",
    "text": "Kalau ga mau dibahas, jangan bikin konten lagi Pa wkwk",
    "date": "2026-10-05",
    "time": "19:42"
  },
  {
    "id": "family-049",
    "direction": "incoming",
    "sender": "bian",
    "text": "Kenan, jangan tambah-tambahin. Papa sudah minta maaf",
    "date": "2026-10-05",
    "time": "19:44"
  },
  {
    "id": "family-050",
    "direction": "incoming",
    "sender": "pian",
    "text": "THEO!!! SIAPA SURUH NYORET-NYORET MEJA KERJA GUE PAKE SPIDOL?! ASTAGA PUSING GUE!",
    "date": "2026-10-08",
    "time": "15:35"
  },
  {
    "id": "family-051",
    "direction": "incoming",
    "sender": "theo",
    "type": "sticker",
    "mediaUrl": "/assets/stickers/theo_crying.png",
    "date": "2026-10-08",
    "time": "15:36"
  },
  {
    "id": "family-052",
    "direction": "incoming",
    "sender": "bian",
    "text": "Bang, udah dong jangan dimarahin terus adeknya. Kasihan itu Theo nangis kejer di ruang tengah.",
    "date": "2026-10-08",
    "time": "15:40"
  },
  {
    "id": "family-053",
    "direction": "incoming",
    "sender": "pian",
    "text": "Meja kayu jati Piii, susah ilangnya ini! Dicoret robot-robotan gede bgt lagi di tengahnya.",
    "date": "2026-10-08",
    "time": "15:42"
  },
  {
    "id": "family-054",
    "direction": "outgoing",
    "text": "Makanya pintu kamar dikunci bang kalo pergi.",
    "date": "2026-10-08",
    "time": "15:56"
  },
  {
    "id": "family-055",
    "direction": "incoming",
    "sender": "bian",
    "text": "Pian, besok pastikan Theo punya kertas gambar sendiri. Jangan taruh spidol dekat meja kerja",
    "date": "2026-10-08",
    "time": "16:10"
  },
  {
    "id": "family-056",
    "direction": "incoming",
    "sender": "pian",
    "text": "Siap Pi. Kertasnya gue beliin juga nanti",
    "date": "2026-10-08",
    "time": "16:12"
  },
  {
    "id": "family-057",
    "direction": "incoming",
    "sender": "theo",
    "text": "Theo janji tidak coret meja lagi",
    "date": "2026-10-08",
    "time": "16:14"
  },
  {
    "id": "family-058",
    "direction": "incoming",
    "sender": "feri",
    "text": "Janji ya, Dek. Kalau mau gambar bilang dulu",
    "date": "2026-10-08",
    "time": "16:16"
  },
  {
    "id": "family-059",
    "direction": "incoming",
    "sender": "kenan",
    "text": "WOI SIAPA YANG NYORET MUKA GUE PAKE SPIDOL PERMANEN!!! BANGUN-BANGUN ITEM SEMUA!!",
    "date": "2026-10-11",
    "time": "14:25"
  },
  {
    "id": "family-060",
    "direction": "incoming",
    "sender": "theo",
    "type": "voice",
    "duration": "0:06",
    "transcript": "Hihihi kak Kenan mukanya kayak kucing ada kumisnya panjang, Theo yang gambar pake spidol kak Pian hihihi.",
    "date": "2026-10-11",
    "time": "14:27"
  },
  {
    "id": "family-061",
    "direction": "incoming",
    "sender": "pian",
    "text": "HAHAHAHAHAHA MAMAM TUH KARMA LU DEK KENA JUGA KAN",
    "date": "2026-10-11",
    "time": "14:28"
  },
  {
    "id": "family-062",
    "direction": "incoming",
    "sender": "esta",
    "text": "Syukurin. Makanya tidur jangan kayak orang mati dibangunin ga bangun.",
    "date": "2026-10-11",
    "time": "14:30"
  },
  {
    "id": "family-063",
    "direction": "incoming",
    "sender": "feri",
    "text": "Pake minyak telon digosok pelan-pelan pake tisu dek ngapusnya.",
    "date": "2026-10-11",
    "time": "14:35"
  },
  {
    "id": "family-064",
    "direction": "incoming",
    "sender": "bian",
    "text": "Anak-anak Papi kenapa pada rusuh banget sih hari Minggu ini Ya Allah 😭",
    "date": "2026-10-11",
    "time": "14:40"
  },
  {
    "id": "family-065",
    "direction": "incoming",
    "sender": "feri",
    "text": "Muka Kenan sudah bersih belum? Papa punya minyak telon kalau masih susah hilang",
    "date": "2026-10-11",
    "time": "14:45"
  },
  {
    "id": "family-066",
    "direction": "incoming",
    "sender": "kenan",
    "text": "Belum Pa, tapi udah mendingan. Jangan kasih Theo spidol permanen lagi",
    "date": "2026-10-11",
    "time": "14:47"
  },
  {
    "id": "family-067",
    "direction": "incoming",
    "sender": "bian",
    "text": "Theo bilang spidolnya punya Bang Pian",
    "date": "2026-10-11",
    "time": "14:49"
  },
  {
    "id": "family-068",
    "direction": "incoming",
    "sender": "pian",
    "text": "Jangan bawa-bawa nama gue, Pi",
    "date": "2026-10-11",
    "time": "14:51"
  },
  {
    "id": "family-069",
    "direction": "incoming",
    "sender": "bian",
    "type": "photo",
    "mediaUrl": "/assets/images/chats/bian_outfit.jpg",
    "text": "Anak-anak, Papi mending pake kemeja maroon apa biru dongker buat kondangan teman arisan besok?",
    "date": "2026-10-13",
    "time": "15:10"
  },
  {
    "id": "family-070",
    "direction": "incoming",
    "sender": "feri",
    "text": "Mustard aja sayang, warna kuning biar cerah mancar kayak matahari ☀️",
    "date": "2026-10-13",
    "time": "15:12"
  },
  {
    "id": "family-071",
    "direction": "incoming",
    "sender": "kenan",
    "text": "Jreng banget norak kayak tukang parkir pa astaga.",
    "date": "2026-10-13",
    "time": "15:15"
  },
  {
    "id": "family-072",
    "direction": "outgoing",
    "text": "Maroon Pi. Udah gausah dengerin saran Papa kalo soal baju, sesat.",
    "date": "2026-10-13",
    "time": "15:26"
  },
  {
    "id": "family-073",
    "direction": "incoming",
    "sender": "bian",
    "text": "Papi sudah pilih maroon. Besok Papa ikut Papi ke acara, jangan sampai telat",
    "date": "2026-10-13",
    "time": "15:30"
  },
  {
    "id": "family-074",
    "direction": "incoming",
    "sender": "feri",
    "text": "Siap sayang. Papa sudah siapkan mobil",
    "date": "2026-10-13",
    "time": "15:32"
  },
  {
    "id": "family-075",
    "direction": "incoming",
    "sender": "kenan",
    "text": "Jangan pakai sepatu yang itu, Pa. Warnanya ga masuk",
    "date": "2026-10-13",
    "time": "15:34"
  },
  {
    "id": "family-076",
    "direction": "incoming",
    "sender": "bian",
    "text": "Kenan, kamu fokus sekolah saja dulu 😭",
    "date": "2026-10-13",
    "time": "15:36"
  },
  {
    "id": "family-077",
    "direction": "incoming",
    "sender": "esta",
    "text": "Tadi adeknya Panji sopan banget. Makasih ya Shaqil sudah nemenin ngobrol",
    "date": "2026-10-18",
    "time": "17:30"
  },
  {
    "id": "family-078",
    "direction": "outgoing",
    "text": "Iya Bang. Dia tadi awalnya tegang, tapi udah cair pas ngobrol sama Papa",
    "date": "2026-10-18",
    "time": "17:33"
  },
  {
    "id": "family-079",
    "direction": "incoming",
    "sender": "bian",
    "text": "Papi juga senang. Lain kali ajak mampir lagi kalau ada waktu",
    "date": "2026-10-18",
    "time": "17:35"
  },
  {
    "id": "family-080",
    "direction": "incoming",
    "sender": "pian",
    "text": "QIL LU KENAPA MASUK RUMAH SAKIT?!",
    "date": "2026-10-20",
    "time": "19:05"
  },
  {
    "id": "family-081",
    "direction": "incoming",
    "sender": "feri",
    "text": "ADEK KAMU KENAPA?? PAPA LIAT DI STORY IG PANJI TANGAN KAMU DI INFUS BERDARAH!! PAPA SAMA PAPI OTW APARTEMEN KAMU SEKARANG JUGA!!",
    "date": "2026-10-20",
    "time": "19:08"
  },
  {
    "id": "family-082",
    "direction": "incoming",
    "sender": "bian",
    "text": "Adekkkkk 😭😭😭 Papi ikut Papa ke sana sekarang! Jangan gerak-gerak ya tangannya sayang!",
    "date": "2026-10-20",
    "time": "19:10"
  },
  {
    "id": "family-083",
    "direction": "incoming",
    "sender": "esta",
    "text": "Dek, parah ga sakitnya? Perlu gue bawain baju ganti sekalian ke sana?",
    "date": "2026-10-20",
    "time": "19:12"
  },
  {
    "id": "family-084",
    "direction": "outgoing",
    "text": "STOP JANGAN ADA YANG KE SINI!! MACET!",
    "date": "2026-10-20",
    "time": "19:14"
  },
  {
    "id": "family-085",
    "direction": "outgoing",
    "text": "Itu cuma infus vitamin astaga! Panji doang lebay difoto-fotoin masuk ke IG! Shaqil di apartemen, ga sakit parah dan ga dirawat inap! Papa Papi diem aja di rumah please.",
    "date": "2026-10-20",
    "time": "19:15"
  },
  {
    "id": "family-086",
    "direction": "incoming",
    "sender": "kenan",
    "text": "Lemah amat lu bang masuk RS kena tipus yak wkwk",
    "date": "2026-10-20",
    "time": "19:16"
  },
  {
    "id": "family-087",
    "direction": "incoming",
    "sender": "feri",
    "text": "Beneran ga perlu disamperin? Awas kamu kalo bohong, besok Papa suruh Panji gembok pintu apartemen kamu biar kamu istirahat.",
    "date": "2026-10-20",
    "time": "19:22"
  },
  {
    "id": "family-088",
    "direction": "incoming",
    "sender": "feri",
    "text": "Yang penting jangan lupa istirahat. Papa ga mau lihat foto infus lagi",
    "date": "2026-10-20",
    "time": "19:25"
  },
  {
    "id": "family-089",
    "direction": "outgoing",
    "text": "Aman Pa. Panji udah di sini, Shaqil istirahat",
    "date": "2026-10-20",
    "time": "19:27"
  },
  {
    "id": "family-090",
    "direction": "incoming",
    "sender": "bian",
    "text": "Papi titip bilang buburnya dihabiskan ya. Jangan cuma dimakan tiga sendok",
    "date": "2026-10-20",
    "time": "19:29"
  },
  {
    "id": "family-091",
    "direction": "incoming",
    "sender": "panji",
    "text": "Gue udah bilang ke Papi, nanti gue awasin",
    "date": "2026-10-20",
    "time": "19:31"
  },
  {
    "id": "family-092",
    "direction": "incoming",
    "sender": "feri",
    "text": "Makasih mantu. Jangan lupa makan juga",
    "date": "2026-10-20",
    "time": "19:33"
  },
  {
    "id": "family-093",
    "direction": "incoming",
    "sender": "bian",
    "text": "Papa, jangan sebut mantu di grup terus. Shaqil nanti besar kepala",
    "date": "2026-10-20",
    "time": "19:35"
  },
  {
    "id": "family-094",
    "direction": "incoming",
    "sender": "feri",
    "text": "Pengumuman! 📢 Nanti malam kita sekeluarga makan di Bebek Pak Ndut. Papa yang traktir. Kumpul jam 7 malam teng tidak ada yang telat!",
    "date": "2026-10-26",
    "time": "18:15"
  },
  {
    "id": "family-095",
    "direction": "incoming",
    "sender": "theo",
    "text": "Yeeeeeay theo mau es teh manis!",
    "date": "2026-10-26",
    "time": "18:20"
  },
  {
    "id": "family-096",
    "direction": "incoming",
    "sender": "bian",
    "text": "Baju yang rapi ya anak-anak, jangan pakai kaos belel.",
    "date": "2026-10-26",
    "time": "18:25"
  },
  {
    "id": "family-097",
    "direction": "incoming",
    "sender": "kenan",
    "text": "Siap meluncur bosku.",
    "date": "2026-10-26",
    "time": "18:30"
  },
  {
    "id": "family-098",
    "direction": "incoming",
    "sender": "feri",
    "text": "Tadi makannya banyak juga. Senang bisa kumpul lengkap",
    "date": "2026-10-26",
    "time": "21:00"
  },
  {
    "id": "family-099",
    "direction": "incoming",
    "sender": "esta",
    "text": "Theo paling senang karena es teh manisnya dua",
    "date": "2026-10-26",
    "time": "21:02"
  },
  {
    "id": "family-100",
    "direction": "incoming",
    "sender": "bian",
    "text": "Satu buat sekarang, satu buat nanti. Jangan dibiasakan ya",
    "date": "2026-10-26",
    "time": "21:04"
  },
  {
    "id": "family-101",
    "direction": "incoming",
    "sender": "theo",
    "text": "Hehehe besok Theo mau lagi",
    "date": "2026-10-26",
    "time": "21:06"
  },
  {
    "id": "family-102",
    "direction": "incoming",
    "sender": "bian",
    "text": "INI SIAPA YANG NUMPAHIN KOPI DI KARPET BULU PAPI DI RUANG TENGAH?!!! 😡😡😡",
    "date": "2026-10-27",
    "time": "13:10"
  },
  {
    "id": "family-103",
    "direction": "incoming",
    "sender": "kenan",
    "text": "Bukan Kenan Pi sumpah, dari pagi Kenan di sekolah.",
    "date": "2026-10-27",
    "time": "13:15"
  },
  {
    "id": "family-104",
    "direction": "incoming",
    "sender": "theo",
    "text": "Theo ga suka kopi.",
    "date": "2026-10-27",
    "time": "13:16"
  },
  {
    "id": "family-105",
    "direction": "incoming",
    "sender": "esta",
    "text": "Esta dari pagi ngerjain laporan di dalem kamar Pi.",
    "date": "2026-10-27",
    "time": "13:20"
  },
  {
    "id": "family-106",
    "direction": "outgoing",
    "text": "Waduh... siapa tuh ya yang numpahin... Coba tanya anak tertua di rumah ini, barangkali dia tau.",
    "date": "2026-10-27",
    "time": "13:35"
  },
  {
    "id": "family-107",
    "direction": "incoming",
    "sender": "pian",
    "type": "sticker",
    "mediaUrl": "/assets/stickers/pian_run_away.png",
    "date": "2026-10-27",
    "time": "13:40"
  },
  {
    "id": "family-108",
    "direction": "incoming",
    "sender": "bian",
    "text": "Papi sudah cek karpet. Siapa pun yang numpahin kopi tolong jujur sebelum Papi cari sendiri",
    "date": "2026-10-27",
    "time": "14:00"
  },
  {
    "id": "family-109",
    "direction": "incoming",
    "sender": "kenan",
    "text": "Beneran bukan gue, Pi. Dari pagi gue di sekolah",
    "date": "2026-10-27",
    "time": "14:02"
  },
  {
    "id": "family-110",
    "direction": "incoming",
    "sender": "theo",
    "text": "Theo ga minum kopi, Papi",
    "date": "2026-10-27",
    "time": "14:04"
  },
  {
    "id": "family-111",
    "direction": "incoming",
    "sender": "feri",
    "text": "Jangan semua langsung defensif. Yang merasa tahu, bantu bersihkan dulu",
    "date": "2026-10-27",
    "time": "14:06"
  },
  {
    "id": "family-112",
    "direction": "incoming",
    "sender": "esta",
    "text": "Papi, sepertinya Bang Pian tadi minum kopi di ruang tengah",
    "date": "2026-10-27",
    "time": "14:20"
  },
  {
    "id": "family-113",
    "direction": "incoming",
    "sender": "pian",
    "text": "ESTA WOI",
    "date": "2026-10-27",
    "time": "14:22"
  },
  {
    "id": "family-114",
    "direction": "incoming",
    "sender": "bian",
    "text": "Nah, sudah ketemu pelakunya. Pian, tolong bersihkan sampai tidak ada bekas",
    "date": "2026-10-27",
    "time": "14:24"
  },
  {
    "id": "family-115",
    "direction": "incoming",
    "sender": "pian",
    "text": "Baik, Pi. Mohon jangan dicoret dari KK",
    "date": "2026-10-27",
    "time": "14:26"
  },
  {
    "id": "family-116",
    "direction": "incoming",
    "sender": "feri",
    "text": "Jangan lupa makan malam di rumah hari ini kalau sempat. Papa masak agak banyak",
    "date": "2026-10-29",
    "time": "18:00"
  },
  {
    "id": "family-117",
    "direction": "outgoing",
    "text": "Shaqil pulang, Pa. Panji juga ikut",
    "date": "2026-10-29",
    "time": "18:03"
  },
  {
    "id": "family-118",
    "direction": "incoming",
    "sender": "bian",
    "text": "Papi sudah siapkan tempat duduk. Hati-hati di jalan",
    "date": "2026-10-29",
    "time": "18:05"
  },
  {
    "id": "family-119",
    "direction": "incoming",
    "sender": "theo",
    "text": "Theo tunggu permen stroberi ya kakak",
    "date": "2026-10-29",
    "time": "18:07"
  },
  {
    "id": "family-120",
    "direction": "outgoing",
    "text": "Iya, jangan dimakan dulu sebelum makan malam",
    "date": "2026-10-29",
    "time": "18:09"
  },
  {
    "id": "family-121",
    "direction": "incoming",
    "sender": "feri",
    "text": "Papa mau foto keluarga habis makan. Jangan ada yang kabur dulu",
    "date": "2026-10-29",
    "time": "20:30"
  },
  {
    "id": "family-122",
    "direction": "incoming",
    "sender": "feri",
    "text": "Kalau fotonya bagus boleh masuk Facebook Papa?",
    "date": "2026-10-29",
    "time": "20:32"
  },
  {
    "id": "family-123",
    "direction": "incoming",
    "sender": "bian",
    "text": "Boleh, asal jangan tag semua teman arisan Papi lagi",
    "date": "2026-10-29",
    "time": "20:34"
  },
  {
    "id": "family-124",
    "direction": "incoming",
    "sender": "kenan",
    "text": "WKWK Papi trauma",
    "date": "2026-10-29",
    "time": "20:36"
  }
];
